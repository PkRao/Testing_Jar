package com.bel.laa

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity(), LocationListener {
    private val CHANNEL = "com.example.gps/location"
    private val GPS_CHANNEL = "com.gps.tracker/location"
    private val PERMISSION_REQUEST_CODE = 1001
    private val BACKGROUND_PERMISSION_REQUEST_CODE = 1002
    private val TAG = "GPSTracker"
    private val NETWORK_UPDATE_INTERVAL = 3000L

    private var methodChannel: MethodChannel? = null
    private var gpsMethodChannel: MethodChannel? = null
    private var locationManager: LocationManager? = null
    private var pendingResult: MethodChannel.Result? = null

    private var wifiManager: WifiManager? = null
    private var telephonyManager: TelephonyManager? = null
    private var connectivityManager: ConnectivityManager? = null

    private var networkUpdateHandler: Handler? = null
    private var networkUpdateRunnable: Runnable? = null
    private var isNetworkMonitoringActive = false

    private var gpsLocationListener: LocationListener? = null
    private var isGPSTrackingActive = false
    private var receiverRegistered = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        networkUpdateHandler = Handler(Looper.getMainLooper())

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermissions" -> {
                    requestLocationPermissions(result)
                }
                "isGPSEnabled" -> {
                    result.success(isGPSEnabled())
                }
                "startLocationUpdates" -> {
                    startLocationUpdates()
                    result.success(null)
                }
                "stopLocationUpdates" -> {
                    stopLocationUpdates()
                    result.success(null)
                }
                "getLastKnownLocation" -> {
                    getLastKnownLocation()
                    result.success(null)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        gpsMethodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, GPS_CHANNEL)
        gpsMethodChannel?.setMethodCallHandler { call, result ->
            Log.d(TAG, "GPS Method called: ${call.method}")
            when (call.method) {
                "startLocationService" -> {
                    requestGPSPermissionsAndStart()
                    result.success(null)
                }
                "stopLocationService" -> {
                    stopGPSTracking()
                    result.success(null)
                }
                "getLastLocation" -> {
                    val location = getLastLocationFromPrefs()
                    result.success(location)
                }
                "saveTokens" -> {
                    val accessToken = call.argument<String>("access_token") ?: ""
                    val refreshToken = call.argument<String>("refresh_token") ?: ""
                    saveTokensToNativeStorage(accessToken, refreshToken)

                    // Notify LocationService that new tokens are available
                    val intent = Intent(this@MainActivity, LocationService::class.java)
                    intent.action = "ACTION_TOKENS_UPDATED"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }

                    result.success(null)
                }
                "clearTokens" -> {  // Clear tokens
                    clearTokensFromNativeStorage()
                    stopService(Intent(this@MainActivity, LocationService::class.java))
                    result.success(null)
                }
                "hasTokens" -> {  // Check if tokens exist
                    val hasTokens = checkTokensExist()
                    result.success(hasTokens)
                }
                "readTokens" -> {  // Read tokens for Flutter UI sync
                    val nativePrefs = getSharedPreferences("com.bel.laa.tokens", MODE_PRIVATE)
                    val tokens = HashMap<String, String?>()
                    tokens["access_token"] = nativePrefs.getString("access_token", null)
                    tokens["refresh_token"] = nativePrefs.getString("refresh_token", null)
                    result.success(tokens)
                }
                "updateGeofence" -> {
                    val geofenceJson = call.argument<String>("geofence_json") ?: ""
                    Log.d(TAG, "updateGeofence called with: ${geofenceJson.take(100)}...")

                    val intent = Intent(this@MainActivity, LocationService::class.java).apply {
                        action = "ACTION_UPDATE_GEOFENCE"
                        putExtra("geofence_json", geofenceJson)
                    }
                    startService(intent)
                    result.success(null)
                }
                "removeGeofence" -> {
                    val zoneId = call.argument<String>("zone_id") ?: ""

                    val intent = Intent(this@MainActivity, LocationService::class.java).apply {
                        action = "ACTION_REMOVE_GEOFENCE"
                        putExtra("zone_id", zoneId)
                    }
                    startService(intent)
                    result.success(null)
                }
                "clearAllGeofences" -> {
                    val intent = Intent(this@MainActivity, LocationService::class.java).apply {
                        action = "ACTION_CLEAR_ALL_GEOFENCES"
                    }
                    startService(intent)
                    result.success(null)
                }
                "saveUserInfo" -> {
                    // Store userId, role, serviceId so the background SocketManagerService can read them
                    val userId    = call.argument<String>("userId") ?: ""
                    val role      = call.argument<String>("role") ?: ""
                    val serviceId = call.argument<String>("serviceId") ?: ""
                    saveUserInfoToNativeStorage(userId, role, serviceId)

                    // Notify LocationService so it reconnects the socket with the new user identity
                    val socketIntent = Intent(this@MainActivity, LocationService::class.java).apply {
                        action = "ACTION_UPDATE_USER_INFO"
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(socketIntent)
                    } else {
                        startService(socketIntent)
                    }
                    result.success(null)
                }
                "clearUserInfo" -> {
                    clearUserInfoFromNativeStorage()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        startNetworkMonitoring()
    }

    private fun clearTokensFromNativeStorage() {
        try {
            val nativePrefs = getSharedPreferences("com.bel.laa.tokens", MODE_PRIVATE)
            nativePrefs.edit().clear().apply()
            Log.d(TAG, "Tokens cleared from native storage")
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing tokens: ${e.message}")
        }
    }

    /** Store userId, role, and serviceId for the background SocketManagerService. */
    private fun saveUserInfoToNativeStorage(userId: String, role: String, serviceId: String) {
        try {
            val prefs = getSharedPreferences("com.bel.laa.userinfo", MODE_PRIVATE)
            prefs.edit().apply {
                putString("userId", userId)
                putString("role", role)
                putString("serviceId", serviceId)
                apply()
            }
            Log.d(TAG, "UserInfo saved to native: userId=$userId, role=$role, serviceId=$serviceId")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving user info: ${e.message}")
        }
    }

    /** Clear user identity on logout so the background socket stops registering. */
    private fun clearUserInfoFromNativeStorage() {
        try {
            val prefs = getSharedPreferences("com.bel.laa.userinfo", MODE_PRIVATE)
            prefs.edit().clear().apply()
            Log.d(TAG, "UserInfo cleared from native storage")
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing user info: ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check tokens on app restore
        val tokenManager = TokenManager(applicationContext)
        if (tokenManager.getValidAccessToken().isNullOrBlank()) {
            Log.w(TAG, "Tokens invalid on app restore - stopping LocationService")
            stopService(Intent(this, LocationService::class.java))
        }
    }

    // Check if tokens exist
    private fun checkTokensExist(): Boolean {
        try {
            val nativePrefs = getSharedPreferences("com.bel.laa.tokens", MODE_PRIVATE)
            val accessToken = nativePrefs.getString("access_token", null)
            val hasTokens = accessToken != null
            Log.d(TAG, "Tokens exist: $hasTokens")
            return hasTokens
        } catch (e: Exception) {
            Log.e(TAG, "Error checking tokens: ${e.message}")
            return false
        }
    }

    //  Now this is a class-level method, not nested inside configureFlutterEngine
    private fun saveTokensToNativeStorage(accessToken: String, refreshToken: String) {
        try {
            val nativePrefs = getSharedPreferences("com.bel.laa.tokens", MODE_PRIVATE)
            nativePrefs.edit().apply {
                putString("access_token", accessToken)
                putString("refresh_token", refreshToken)
                apply()
            }
            Log.d(TAG, " Tokens saved to native storage")
            Log.d(TAG, " Token: ${accessToken.take(20)}...")
        } catch (e: Exception) {
            Log.e(TAG, " Error saving tokens: ${e.message}")
        }
    }

    // ============ GPS Permissions ============
    private fun requestGPSPermissionsAndStart() {
        Log.d(TAG, " Requesting GPS permissions...")

        val hasLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (hasLocation) {
            Log.d(TAG, "Foreground location permission already granted")
            requestBackgroundPermission()

            // Also request notification permission if not granted on Android 13+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                            PERMISSION_REQUEST_CODE
                    )
                }
            }
        }
        else {
            Log.d(TAG, " Requesting foreground permissions...")
            val foregroundPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.POST_NOTIFICATIONS
                )
            } else {
                arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                )
            }
            ActivityCompat.requestPermissions(
                    this,
                    foregroundPermissions,
                    PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun requestBackgroundPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val backgroundPermission = Manifest.permission.ACCESS_BACKGROUND_LOCATION

            if (ContextCompat.checkSelfPermission(this, backgroundPermission)
                    != PackageManager.PERMISSION_GRANTED
            ) {
                Log.d(TAG, "📍 Requesting background permission (Android 11+)...")
                ActivityCompat.requestPermissions(
                        this,
                        arrayOf(backgroundPermission),
                        BACKGROUND_PERMISSION_REQUEST_CODE
                )
            } else {
                Log.d(TAG, "✅ Background permission already granted")
                startLocationService()
            }
        } else {
            Log.d(TAG, "ℹ️ Android 10 or below, skipping background permission")
            startLocationService()
        }
    }

    private fun requestLocationPermissions(result: MethodChannel.Result) {
        if (hasLocationPermissions()) {
            result.success(true)
            return
        }

        pendingResult = result
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_WIFI_STATE
            )
        }
        ActivityCompat.requestPermissions(
                this,
                permissions,
                PERMISSION_REQUEST_CODE
        )
    }

    private fun hasLocationPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun isGPSEnabled(): Boolean {
        return locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) ?: false
    }

    // ============ Network monitoring ============
    private fun startNetworkMonitoring() {
        if (isNetworkMonitoringActive) {
            Log.d(TAG, "Network monitoring already active")
            return
        }

        isNetworkMonitoringActive = true
        Log.d(TAG, "Starting independent network monitoring")

        networkUpdateRunnable = object : Runnable {
            override fun run() {
                try {
                    val networkInfo = getNetworkInfo()
                    val timestamp = System.currentTimeMillis()

                    val networkData = HashMap<String, Any>()
                    networkData["networkInfo"] = networkInfo
                    networkData["timestamp"] = timestamp
                    networkData["updateType"] = "network_only"

                    methodChannel?.invokeMethod("onNetworkUpdate", networkData)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in network monitoring", e)
                }

                if (isNetworkMonitoringActive) {
                    networkUpdateHandler?.postDelayed(this, NETWORK_UPDATE_INTERVAL)
                }
            }
        }

        networkUpdateHandler?.post(networkUpdateRunnable!!)
    }

    private fun stopNetworkMonitoring() {
        isNetworkMonitoringActive = false
        networkUpdateRunnable?.let {
            networkUpdateHandler?.removeCallbacks(it)
        }
        Log.d(TAG, "Network monitoring stopped")
    }

    private fun startLocationUpdates() {
        if (!hasLocationPermissions()) {
            methodChannel?.invokeMethod("onLocationError", "Permission not granted")
            return
        }

        try {
            @Suppress("MissingPermission")
            locationManager?.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    3000L,
                    0f,
                    this
            )
        } catch (e: SecurityException) {
            methodChannel?.invokeMethod("onLocationError", "Security exception: ${e.message}")
        }
    }

    private fun stopLocationUpdates() {
        try {
            locationManager?.removeUpdates(this)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping location updates", e)
        }
    }

    private fun getLastKnownLocation() {
        if (!hasLocationPermissions()) return

        try {
            @Suppress("MissingPermission")
            val location = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (location != null) {
                val locationData = HashMap<String, Any>()
                locationData["latitude"] = location.latitude
                locationData["longitude"] = location.longitude
                locationData["accuracy"] = location.accuracy.toDouble()
                locationData["altitude"] = location.altitude
                locationData["speed"] = location.speed.toDouble()
                locationData["provider"] = location.provider ?: "unknown"
                locationData["timestamp"] = location.time
                locationData["updateType"] = "last_known"
                locationData["networkInfo"] = getNetworkInfo()

                methodChannel?.invokeMethod("onLocationUpdate", locationData)
            } else {
                methodChannel?.invokeMethod("onLocationError", "No last known location available")
            }
        } catch (e: SecurityException) {
            methodChannel?.invokeMethod("onLocationError", "Security exception: ${e.message}")
        }
    }

    // ============ Start Location Service ============
    private fun startLocationService() {
        Log.d(TAG, "Starting LocationService...")
        val intent = Intent(this, LocationService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
            Log.d(TAG, "Foreground service started")
        } else {
            startService(intent)
            Log.d(TAG, "Service started")
        }
    }

    private fun startGPSTracking() {
        if (isGPSTrackingActive) {
            Log.d(TAG, "GPS tracking already active")
            return
        }

        if (!hasLocationPermissions()) {
            Log.w(TAG, "Location permissions not granted")
            return
        }

        isGPSTrackingActive = true
        Log.d(TAG, "Starting GPS tracking")

        try {
            val provider = when {
                locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true -> {
                    Log.d(TAG, "Using GPS_PROVIDER")
                    LocationManager.GPS_PROVIDER
                }
                locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true -> {
                    Log.d(TAG, "Using NETWORK_PROVIDER")
                    LocationManager.NETWORK_PROVIDER
                }
                else -> {
                    Log.w(TAG, "No location provider available")
                    gpsMethodChannel?.invokeMethod("onLocationError", "No location provider enabled")
                    return
                }
            }

            gpsLocationListener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    Log.d(TAG, "GPS Location changed: ${location.latitude}, ${location.longitude}")

                    val locationData = HashMap<String, Any>()
                    locationData["latitude"] = location.latitude
                    locationData["longitude"] = location.longitude
                    locationData["accuracy"] = location.accuracy.toDouble()
                    locationData["altitude"] = location.altitude
                    locationData["speed"] = location.speed.toDouble()
                    locationData["timestamp"] = location.time
                    locationData["provider"] = location.provider ?: "unknown"

                    saveGPSLocationToPrefs(location.latitude, location.longitude, location.time)

                    gpsMethodChannel?.invokeMethod("locationUpdate", locationData)
                }

                override fun onProviderEnabled(provider: String) {
                    Log.d(TAG, "GPS Provider enabled: $provider")
                }

                override fun onProviderDisabled(provider: String) {
                    Log.w(TAG, "GPS Provider disabled: $provider")
                    gpsMethodChannel?.invokeMethod("onLocationError", "GPS provider disabled")
                }

                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                    Log.d(TAG, "GPS Status changed: $provider -> $status")
                }
            }

            @Suppress("MissingPermission")
            locationManager?.requestLocationUpdates(provider, 3000L, 0f, gpsLocationListener!!)

            @Suppress("MissingPermission")
            val lastKnown = locationManager?.getLastKnownLocation(provider)
            lastKnown?.let {
                Log.d(TAG, "Last known location: ${it.latitude}, ${it.longitude}")

                val locationData = HashMap<String, Any>()
                locationData["latitude"] = it.latitude
                locationData["longitude"] = it.longitude
                locationData["accuracy"] = it.accuracy.toDouble()
                locationData["altitude"] = it.altitude
                locationData["speed"] = it.speed.toDouble()
                locationData["timestamp"] = it.time
                locationData["provider"] = it.provider ?: "unknown"

                saveGPSLocationToPrefs(it.latitude, it.longitude, it.time)
                gpsMethodChannel?.invokeMethod("locationUpdate", locationData)
            }

            Log.d(TAG, "GPS tracking started successfully")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException in GPS tracking: ${e.message}")
            gpsMethodChannel?.invokeMethod("onLocationError", "Permission denied: ${e.message}")
        }
    }

    private fun stopGPSTracking() {
        if (!isGPSTrackingActive) return

        isGPSTrackingActive = false
        Log.d(TAG, "Stopping GPS tracking")

        try {
            gpsLocationListener?.let {
                locationManager?.removeUpdates(it)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping GPS tracking: ${e.message}")
        }
    }

    private fun saveGPSLocationToPrefs(lat: Double, lon: Double, time: Long) {
        Log.d(TAG, "GPS location saving  lat= $lat, lon=$lon, timestamp=$time")

        val prefs = getSharedPreferences("location_prefs", MODE_PRIVATE)
        prefs.edit().apply {
            putFloat("latitude", lat.toFloat())
            putFloat("longitude", lon.toFloat())
            putLong("timestamp", time)
            apply()
        }
        Log.d(TAG, "GPS location saved to SharedPreferences")
    }

    private fun getLastLocationFromPrefs(): Map<String, Any> {
        val prefs = getSharedPreferences("location_prefs", MODE_PRIVATE)
        val latitude = prefs.getFloat("latitude", 0f).toDouble()
        val longitude = prefs.getFloat("longitude", 0f).toDouble()
        val timestamp = prefs.getLong("timestamp", 0L)

        Log.d(TAG, "Last location from prefs : lat= $latitude, lon=$longitude, timestamp=$timestamp")

        return mapOf(
                "latitude" to latitude,
                "longitude" to longitude,
                "timestamp" to timestamp
        )
    }

    // ============ Permission Result Handler ============
    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                val granted = hasLocationPermissions()

                Log.d(TAG, "🔐 Foreground permissions granted: $granted")

                if (granted) {
                    pendingResult?.success(granted)
                    pendingResult = null
                    requestBackgroundPermission()

                    // Notify LocationService that permissions are granted so it can register its listener
                    val intent = Intent(this, LocationService::class.java)
                    intent.action = "ACTION_PERMISSIONS_GRANTED"
                    startService(intent)
                } else {
                    Log.w(TAG, "❌ Foreground permissions denied")
                    pendingResult?.success(false)
                    pendingResult = null
                }
            }

            BACKGROUND_PERMISSION_REQUEST_CODE -> {
                val granted = grantResults.isNotEmpty() &&
                        grantResults.all { it == PackageManager.PERMISSION_GRANTED }

                if (granted) {
                    Log.d(TAG, "✅ Background permission granted")
                } else {
                    Log.w(TAG, "⚠️ Background permission denied (foreground only)")
                }

                startLocationService()

                val intent = Intent(this, LocationService::class.java)
                intent.action = "ACTION_PERMISSIONS_GRANTED"
                startService(intent)
            }
        }
    }

    // ============ Network Info ============
    private fun getNetworkInfo(): Map<String, Any> {
        val networkData = mutableMapOf<String, Any>()

        try {
            var connectionType = "Unknown"
            try {
                val activeNetwork = connectivityManager?.activeNetwork
                val capabilities = connectivityManager?.getNetworkCapabilities(activeNetwork)
                when {
                    capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> connectionType = "WiFi"
                    capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> connectionType = "Cellular"
                }
            } catch (e: Exception) {
                Log.d(TAG, "ConnectivityManager check failed: ${e.message}")
            }

            val wifiData = collectWiFiInfo()
            if (wifiData.isNotEmpty()) {
                networkData.putAll(wifiData)
            }

            val cellularData = collectCellularInfo()
            if (cellularData.isNotEmpty()) {
                networkData.putAll(cellularData)
            }

            networkData["connectionType"] = connectionType
        } catch (e: Exception) {
            Log.e(TAG, "Error collecting network info", e)
        }

        return networkData
    }

    private fun collectWiFiInfo(): Map<String, Any> {
        val wifiData = mutableMapOf<String, Any>()

        try {
            if (wifiManager?.isWifiEnabled == false) return wifiData

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
            ) {
                return wifiData
            }

            val wifiInfo = wifiManager?.connectionInfo ?: return wifiData

            val ssid = wifiInfo.ssid?.replace("\"", "")
            if (ssid != null && ssid != "<unknown ssid>") {
                wifiData["wifiSSID"] = ssid
            }

            val bssid = wifiInfo.bssid
            if (bssid != null) wifiData["wifiBSSID"] = bssid

            wifiData["wifiRSSI"] = wifiInfo.rssi
        } catch (e: Exception) {
            Log.e(TAG, "Error collecting WiFi info", e)
        }

        return wifiData
    }

    private fun collectCellularInfo(): Map<String, Any> {
        val cellularData = mutableMapOf<String, Any>()

        try {
            val hasLocationPermission = ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (!hasLocationPermission) return cellularData

            val cellInfoList = try {
                telephonyManager?.allCellInfo
            } catch (se: SecurityException) {
                return cellularData
            } catch (e: Exception) {
                return cellularData
            }

            if (cellInfoList == null || cellInfoList.isEmpty()) return cellularData

            val cellInfo = cellInfoList.firstOrNull { it.isRegistered } ?: cellInfoList.firstOrNull() ?: return cellularData

            when (cellInfo) {
                is CellInfoLte -> cellularData["networkType"] = "LTE"
                is CellInfoWcdma -> cellularData["networkType"] = "WCDMA"
                is CellInfoGsm -> cellularData["networkType"] = "GSM"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error collecting cellular info", e)
        }

        return cellularData
    }

    // ============ LocationListener callbacks ============
    override fun onLocationChanged(location: Location) {
        val locationData = HashMap<String, Any>()

        locationData["latitude"] = location.latitude
        locationData["longitude"] = location.longitude
        locationData["accuracy"] = location.accuracy.toDouble()
        locationData["altitude"] = location.altitude
        locationData["speed"] = location.speed.toDouble()
        locationData["provider"] = location.provider ?: "unknown"
        locationData["timestamp"] = location.time

        val networkInfo = getNetworkInfo()
        locationData["networkInfo"] = networkInfo
        locationData["updateType"] = "gps_update"

        methodChannel?.invokeMethod("onLocationUpdate", locationData)

        // Ensure Background Service gets the exact same location!
        // This solves OS throttling where foreground activity starves background listeners.
        try {
            val intent = Intent(this, LocationService::class.java).apply {
                action = "ACTION_FORCE_LOCATION_UPDATE"
                putExtra("latitude", location.latitude)
                putExtra("longitude", location.longitude)
                putExtra("accuracy", location.accuracy)
                putExtra("altitude", location.altitude)
                putExtra("speed", location.speed)
                putExtra("provider", location.provider)
                putExtra("time", location.time)
            }
            startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to forward location to service", e)
        }
    }

    override fun onProviderEnabled(provider: String) {
        Log.d(TAG, "Provider enabled: $provider")
    }

    override fun onProviderDisabled(provider: String) {
        Log.d(TAG, "Provider disabled: $provider")
        methodChannel?.invokeMethod("onLocationError", "GPS provider disabled")
    }

    @Deprecated("Deprecated in API level 29")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume called")
        if (isGPSTrackingActive) {
            startLocationService()
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause called")
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy called")
        stopLocationUpdates()
        stopNetworkMonitoring()
        super.onDestroy()
    }

}












/*



package com.example.location_aware

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
*/

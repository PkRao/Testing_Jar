package com.bel.laa

import android.content.Context
import android.util.Log
import java.util.Base64
import org.json.JSONObject

class TokenManager(private val context: Context) {
    
    companion object {
        private const val TAG = "TokenManager"
        private const val NATIVE_TOKEN_STORAGE = "com.bel.laa.tokens"
    }

    private val prefs by lazy {
        context.getSharedPreferences(NATIVE_TOKEN_STORAGE, Context.MODE_PRIVATE)
    }

    // Check if token is expired
    fun isTokenExpired(token: String?): Boolean {
        if (token.isNullOrBlank()) {
            Log.w(TAG, "Token is null or blank")
            return true
        }

        return try {
            val decodedToken = decodeToken(token)
            val expirationTime = decodedToken.optLong("exp", 0) * 1000  // Convert to milliseconds
            val currentTime = System.currentTimeMillis()

            if (currentTime > expirationTime) {
                Log.w(TAG, "Token expired. Current: $currentTime, Expiration: $expirationTime")
                true
            } else {
                val timeRemaining = (expirationTime - currentTime) / 1000
                Log.d(TAG, "Token valid. Expires in $timeRemaining seconds")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking token expiration: ${e.message}")
            true  // If we can't decode, assume it's expired
        }
    }

    // Decode JWT token
    private fun decodeToken(token: String): JSONObject {
        try {
            val parts = token.split(".")
            if (parts.size != 3) {
                throw IllegalArgumentException("Invalid token format")
            }

            val decodedBytes = Base64.getDecoder().decode(parts[1])
            val decodedString = String(decodedBytes, Charsets.UTF_8)
            return JSONObject(decodedString)
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding token: ${e.message}")
            throw e
        }
    }

    // Get access token with expiration check
    fun getValidAccessToken(): String? {
        val token = prefs.getString("access_token", null)
        
        return if (isTokenExpired(token)) {
            Log.w(TAG, "Access token is expired")
            null  // Return null so we know to refresh
        } else {
            token
        }
    }

    // Get refresh token
    fun getRefreshToken(): String? {
        return prefs.getString("refresh_token", null)
    }

    // Save tokens
    fun saveTokens(accessToken: String, refreshToken: String) {
        prefs.edit().apply {
            putString("access_token", accessToken)
            putString("refresh_token", refreshToken)
            apply()
        }
        Log.d(TAG, "Tokens saved")
    }

    // Clear tokens
    fun clearTokens() {
        prefs.edit().clear().apply()
        Log.d(TAG, "Tokens cleared")
    }
}
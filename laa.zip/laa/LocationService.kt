package com.bel.laa

import android.app.*
import android.content.*
import android.location.*
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.*
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import okhttp3.MediaType.Companion.toMediaTypeOrNull


class LocationService : Service() {

    companion object {
        private const val TAG = "LocationService"
        private const val NOTIF_ID = 100
        private const val CHANNEL_ID = "location_tracking_v2"
        private const val GEOFENCE_CHANNEL_ID = "geofence_alerts"
        private const val GEOFENCE_NOTIF_ID_BASE = 200
        private const val MIN_DISTANCE = 2f
        private const val MIN_TIME = 3000L
    }

    private lateinit var locationManager: LocationManager
    private lateinit var tokenManager: TokenManager
    private val client: OkHttpClient = createUnsafeOkHttpClient()
    private val prefs by lazy { getSharedPreferences("location_prefs", Context.MODE_PRIVATE) }
    private lateinit var geofenceMonitor: GeofenceMonitor
    private var geofenceNotifCounter = 0
    private var socketManager: SocketManagerService? = null
    private lateinit var backgroundSyncManager: BackgroundSyncManager

    private var lastSentTime = 0L
    private var lastSentLocation: Location? = null
    private var isRefreshingToken = false
    private var isListenerRegistered = false
    
    private var lastSyncStatus = "Initializing"
    private var lastLocationTime: String = "—"
    private var lastLocationLat: String = "—"
    private var lastLocationLng: String = "—"

    // ── Network change detection ──────────────────────────────────────────────
    private var connectivityManager: ConnectivityManager? = null

    /**
     * Called by Android when a NEW network becomes available (Wi-Fi roamed,
     * user switched network, etc.).
     *
     * We give the interface 1.5 s to settle (ARP, DNS cache flush) and then
     * call socketManager.forceReconnect() so the dead old-network TCP
     * connection is replaced by a fresh one. Since laa.bel.tcs resolves to
     * a different IP per physical network, the reconnect will land on the
     * correct server automatically.
     */
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            Log.d(TAG, "🔄 New network available — scheduling socket reconnect")
            Handler(Looper.getMainLooper()).postDelayed({
                socketManager?.forceReconnect()
                Log.d(TAG, "🔄 socketManager.forceReconnect() triggered after network switch")
            }, 1500L)
        }
    }

    private fun createUnsafeOkHttpClient(): OkHttpClient {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())
            val sslSocketFactory = sslContext.socketFactory

            return OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
                .hostnameVerifier { _, _ -> true }
                .build()
        } catch (e: Exception) {
            Log.e(TAG, "Error creating OkHttpClient: ${e.message}")
            return OkHttpClient()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "LocationService created")

        try {
            tokenManager = TokenManager(applicationContext)
            geofenceMonitor = GeofenceMonitor(applicationContext)
            Log.d(TAG, "GeofenceMonitor loaded with ${geofenceMonitor.zoneCount()} persisted zones")
            createNotificationChannel()
            createGeofenceNotificationChannel()
            startForeground(NOTIF_ID, buildNotification("Initializing...", "—", "—", "—"))
            locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            requestLocationUpdates()

            // Initialise background socket for group geofence notifications
            initSocketManager()

            // Initialise background API sync (fence list + future endpoints)
            initSyncManager()

            // Register network callback to proactively reconnect socket on network switch
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkRequest = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager?.registerNetworkCallback(networkRequest, networkCallback)
            Log.d(TAG, "NetworkCallback registered")
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate: ${e.message}")
            stopSelf()  // Don't leave service in bad state
        }
    }

    // ── Background API Sync ───────────────────────────────────────────────────

    /**
     * Set up [BackgroundSyncManager] with all periodic background API tasks.
     *
     * To add a new background API in the future, simply call:
     *   backgroundSyncManager.register("my_task") { token -> ... }
     * before or after start() — tasks registered while the manager is running
     * will be picked up on the next cycle automatically.
     */
    private fun initSyncManager() {
        backgroundSyncManager = BackgroundSyncManager(tokenManager, client)

        // ── Task 1: Geofence list refresh ─────────────────────────────────
        // Mirrors GisRefreshService.getCurrentUserFencesList() in Flutter.
        // Fetches /gis/fence_list, parses the response, and updates
        // GeofenceMonitor so background breach detection stays current.
        backgroundSyncManager.register("fence_refresh") { token ->
            val request = Request.Builder()
                .url(AppConfig.getFenceListUrl())
                .header("Authorization", token)
                .get()
                .build()

            client.newCall(request).enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                    Log.e(TAG, "[fence_refresh] HTTP failure: ${e.message}")
                }

                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    response.use { resp ->
                        if (!resp.isSuccessful) {
                            Log.w(TAG, "[fence_refresh] Server returned ${resp.code}")
                            return
                        }
                        try {
                            parseFenceListResponse(resp.body?.string() ?: return)
                        } catch (e: Exception) {
                            Log.e(TAG, "[fence_refresh] Parse error: ${e.message}")
                        }
                    }
                }
            })
        }

        // ── Future tasks — add here ───────────────────────────────────────
        // backgroundSyncManager.register("members_refresh") { token -> ... }
        // backgroundSyncManager.register("notifications_refresh") { token -> ... }

        // Start with a 5-second initial delay so the service settles first
        backgroundSyncManager.start(
            intervalMs    = 2 * 60 * 1000L,  // every 2 minutes
            initialDelayMs = 5_000L
        )
        Log.d(TAG, "BackgroundSyncManager started")
    }

    /**
     * Parse the /gis/fence_list API response and apply updates to [GeofenceMonitor].
     *
     * Expected server shape (same as Flutter):
     * {
     *   "data": [
     *     {
     *       "id": "...",
     *       "fence_name": "...",
     *       "fencing_boundary": [ [lat, lng], [lat, lng], ... ]
     *     },
     *     ...
     *   ]
     * }
     *
     * The monitor is first cleared of all GROUP-type zones so deleted fences
     * on the server are also removed locally.  Only zones with ≥ 3 points
     * are registered (same validation as GeofenceMonitor.registerZone).
     */
    private fun parseFenceListResponse(body: String) {
        val root = org.json.JSONObject(body)
        val data = root.optJSONArray("data") ?: run {
            Log.w(TAG, "[fence_refresh] Response has no 'data' array")
            return
        }

        // Remove stale GROUP zones before re-applying the fresh list
        geofenceMonitor.removeZonesByType("GROUP")

        var registered = 0
        for (i in 0 until data.length()) {
            try {
                val fence    = data.getJSONObject(i)
                val id       = fence.optString("id", "")
                if (id.isBlank()) continue
                //------------- old code ----------------------
                val name     = fence.optString("fence_name", "Group Geofence")
                val boundary = fence.optJSONArray("fencing_boundary") ?: continue
                //------------- old code ----------------------

//                val name     = fence.optString("fenceName", "Group Geofence")
//                val boundary = fence.optJSONArray("fencingBoundary") ?: continue
                //------------- new code ----------------------

                val points = mutableListOf<DoubleArray>()
                for (j in 0 until boundary.length()) {
                    val pt = boundary.getJSONArray(j)
                    points.add(doubleArrayOf(pt.getDouble(0), pt.getDouble(1)))
                }

                if (points.size >= 3) {
                    geofenceMonitor.registerZone(id, name, "GROUP", points)
                    registered++
                } else {
                    Log.w(TAG, "[fence_refresh] Fence '$name' skipped: only ${points.size} points")
                }
            } catch (e: Exception) {
                Log.e(TAG, "[fence_refresh] Error parsing fence at index $i: ${e.message}")
            }
        }
        Log.d(TAG, "[fence_refresh] Registered $registered fence(s) from API")
    }

    /** Create and connect the socket manager. Safe to call multiple times. */
    private fun initSocketManager() {
        try {
            if (socketManager != null) return
            socketManager = SocketManagerService(applicationContext) { message ->
                // Callback fires on any thread — fire geofence alert on main thread
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Log.d(TAG, "🔔 groupNotification from socket: $message")
                    fireGroupAdminNotification(message)
                }
            }
            socketManager?.connect()
            Log.d(TAG, "SocketManagerService initialised")
        } catch (e: Exception) {
            Log.e(TAG, "Error initialising SocketManagerService: ${e.message}")
        }
    }

    /** Show an Android heads-up notification when this admin device receives a groupNotification. */
    private fun fireGroupAdminNotification(message: String) {
        try {
            geofenceNotifCounter++
            val notifId = GEOFENCE_NOTIF_ID_BASE + geofenceNotifCounter

            // Vibrate (short, just to draw attention)
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(500, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500L)
            }

            val notification = androidx.core.app.NotificationCompat.Builder(this, GEOFENCE_CHANNEL_ID)
                .setContentTitle("Group Geofence Alert")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setColor(0xFFFF5252.toInt())
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_SOUND)
                .build()

            getSystemService(NotificationManager::class.java).notify(notifId, notification)
            Log.d(TAG, "Group admin notification shown: $message")
        } catch (e: Exception) {
            Log.e(TAG, "Error showing group admin notification: ${e.message}")
        }
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service started. Action: ${intent?.action}")
        
        if (intent?.action == "ACTION_TOKENS_UPDATED") {
            Log.d(TAG, "Tokens updated from UI, resuming sync...")
            isRefreshingToken = false // Reset refresh lock
            
            // If we have a recent location, immediately retry sync with the fresh tokens
            val lastLoc = lastSentLocation
            if (lastLoc != null) {
                Log.d(TAG, "Re-syncing last known location with fresh tokens...")
                lastSyncStatus = "Syncing..."
                updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                sendToServer(lastLoc.latitude, lastLoc.longitude, System.currentTimeMillis())
            } else {
                lastSyncStatus = "Waiting for GPS..."
                updateNotification(lastSyncStatus, "—", "—", "—")
            }
        } else if (intent?.action == "ACTION_UPDATE_USER_INFO") {
            // User info updated (userId/role) — reconnect socket so it registers correctly
            Log.d(TAG, "User info updated — reconnecting socket...")
            try {
                socketManager?.disconnect()
                socketManager = null
                initSocketManager()
            } catch (e: Exception) {
                Log.e(TAG, "Error reconnecting socket after user info update: ${e.message}")
            }
        } else if (intent?.action == "ACTION_FORCE_LOCATION_UPDATE") {
            val lat = intent.getDoubleExtra("latitude", 0.0)
            val lon = intent.getDoubleExtra("longitude", 0.0)
            if (lat != 0.0 && lon != 0.0) {
                val loc = Location(intent.getStringExtra("provider") ?: LocationManager.GPS_PROVIDER).apply {
                    latitude = lat
                    longitude = lon
                    accuracy = intent.getFloatExtra("accuracy", 0f)
                    altitude = intent.getDoubleExtra("altitude", 0.0)
                    speed = intent.getFloatExtra("speed", 0f)
                    time = intent.getLongExtra("time", System.currentTimeMillis())
                }
                processLocation(loc)
            }
            
            // If the native listener wasn't registered because the service started before 
            // permissions were granted, register it now since we know permissions are available!
            if (!isListenerRegistered) {
                Log.d(TAG, "Permissions available via UI forwarding. Registering native listener...")
                requestLocationUpdates()
            }
        } else if (intent?.action == "ACTION_PERMISSIONS_GRANTED") {
            Log.d(TAG, "Permissions were just granted by the user.")
            if (!isListenerRegistered) {
                requestLocationUpdates()
            }
        } else if (intent?.action == "ACTION_UPDATE_GEOFENCE") {
            val jsonStr = intent.getStringExtra("geofence_json") ?: ""
            handleGeofenceUpdate(jsonStr)
        } else if (intent?.action == "ACTION_REMOVE_GEOFENCE") {
            val zoneId = intent.getStringExtra("zone_id") ?: ""
            if (zoneId.isNotEmpty()) {
                geofenceMonitor.removeZone(zoneId)
                Log.d(TAG, "Geofence zone removed: $zoneId")
            }
        } else if (intent?.action == "ACTION_CLEAR_ALL_GEOFENCES") {
            geofenceMonitor.clearAllZones()
            Log.d(TAG, "All geofence zones cleared")
        } else {
            updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
        }
        
        return START_STICKY
    }

    private fun requestLocationUpdates() {
        try {
            val provider = when {
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> {
                    Log.d(TAG, "Using GPS provider")
                    LocationManager.GPS_PROVIDER
                }
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> {
                    Log.d(TAG, "Using Network provider")
                    LocationManager.NETWORK_PROVIDER
                }
                else -> {
                    Log.w(TAG, "No location provider available")
                    updateNotification("No location provider", "—", "—", "—")
                    return
                }
            }

            @Suppress("MissingPermission")
            locationManager.requestLocationUpdates(provider, MIN_TIME, MIN_DISTANCE, locationListener)
            isListenerRegistered = true

            @Suppress("MissingPermission")
            val lastKnown = locationManager.getLastKnownLocation(provider)
            lastKnown?.let {
                Log.d(TAG, "Last known location: ${it.latitude}, ${it.longitude}")
                processLocation(it)
            }
            
            Log.d(TAG, "Location updates requested")
        } catch (e: SecurityException) {
            isListenerRegistered = false
            Log.e(TAG, "Permission denied: $e")
            updateNotification("Waiting for Permissions", "—", "—", "—")
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            Log.d(TAG, "Location changed: ${location.latitude}, ${location.longitude}")
            processLocation(location)
        }

        override fun onProviderEnabled(provider: String) {
            Log.d(TAG, "Provider enabled: $provider")
        }

        override fun onProviderDisabled(provider: String) {
            Log.w(TAG, "Provider disabled: $provider")
            updateNotification("Provider disabled", "—", "—", "—")
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private fun processLocation(location: Location) {
        val currentTime = System.currentTimeMillis()
        val lastLoc = lastSentLocation
        val distance = lastLoc?.distanceTo(location) ?: Float.MAX_VALUE
        val timeDiff = currentTime - lastSentTime

        val shouldSend = lastLoc == null ||
                distance >= MIN_DISTANCE

        if (!shouldSend) {
            Log.d(TAG, "Skipping update: distance=$distance, timeDiff=$timeDiff")
            return
        }

        lastSentTime = currentTime
        lastSentLocation = location

        saveLocationToPrefs(location.latitude, location.longitude, currentTime)

        lastLocationLat = String.format("%.6f", location.latitude)
        lastLocationLng = String.format("%.6f", location.longitude)
        lastLocationTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(currentTime))
        
        updateNotification("Syncing...", lastLocationLat, lastLocationLng, lastLocationTime)

        // Check geofence zones
        checkGeofences(location.latitude, location.longitude)

        sendToServer(location.latitude, location.longitude, currentTime)
    }

    private fun saveLocationToPrefs(lat: Double, lon: Double, time: Long) {
        prefs.edit().apply {
            putFloat("latitude", lat.toFloat())
            putFloat("longitude", lon.toFloat())
            putLong("timestamp", time)
            apply()
        }
        Log.d(TAG, "Location saved")
    }

    // ============ Server Communication ============

    private fun sendToServer(lat: Double, lon: Double, timestamp: Long) {
        // Check if token is expired
        val token = tokenManager.getValidAccessToken()
        
        if (token.isNullOrBlank()) {
            Log.w(TAG, "No valid token found")
            lastSyncStatus = "Token expired, refreshing..."
            updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
            
            // Try to refresh immediately
            refreshTokenAndRetry(lat, lon, timestamp)
            return
        }

        Log.d(TAG, "Sending location to server...")

        val json = JSONObject().apply {
            put("mdm_node__id", 1)
            put("latitude", lat)
            put("longitude", lon)
            put("battery_avail", 5)
            put("createdTime", timestamp)
        }.toString()

        val body = RequestBody.create("application/json".toMediaTypeOrNull(), json)
        val request = Request.Builder()
            .url(AppConfig.getLocationUrl())
            .header("Authorization", token)
            .post(body)
            .build()

        Log.d(TAG, "POST ${AppConfig.getLocationUrl()}")
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Request failed: ${e.message}")
                lastSyncStatus = "Sync failed"
                updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
            }

            override fun onResponse(call: Call, response: Response) {
                when (response.code) {
                    in 200..299 -> {
                        Log.d(TAG, "Location sent successfully")
                        lastSyncStatus = "Last synced: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}"
                        updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                    }
                    401 -> {
                        Log.w(TAG, "Token expired (401), attempting refresh...")
                        lastSyncStatus = "Refreshing credentials..."
                        updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                        refreshTokenAndRetry(lat, lon, timestamp)
                    }
                    403 -> {
                        Log.e(TAG, "Forbidden (403): Token may be invalid")
                        lastSyncStatus = "Refreshing credentials..."
                        updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                        refreshTokenAndRetry(lat, lon, timestamp)
                    }
                    else -> {
                        Log.e(TAG, "Server error: ${response.code}")
                        lastSyncStatus = "Error: ${response.code}"
                        updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                    }
                }
                response.close()
            }
        })
    }

    private fun refreshTokenAndRetry(lat: Double, lon: Double, timestamp: Long) {
        if (isRefreshingToken) {
            Log.w(TAG, "Token refresh already in progress")
            return
        }

        isRefreshingToken = true
        val refreshToken = tokenManager.getRefreshToken()

        if (refreshToken.isNullOrBlank()) {
            Log.w(TAG, "No refresh token available")
            isRefreshingToken = false
            lastSyncStatus = "Authentication required - please log in"
            updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
            return
        }

        Log.d(TAG, "Refreshing token...")

        val json = JSONObject().apply {
            put("refreshToken", refreshToken)  // Match Flutter APIClient format
        }.toString()

        val body = RequestBody.create("application/json".toMediaTypeOrNull(), json)
        val request = Request.Builder()
            .url(AppConfig.getRefreshTokenUrl())
            .post(body)
            .build()

        Log.d(TAG, "POST ${AppConfig.getRefreshTokenUrl()}")

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Token refresh failed: ${e.message}")
                isRefreshingToken = false
                lastSyncStatus = "Refresh failed"
                updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
            }

            override fun onResponse(call: Call, response: Response) {
                isRefreshingToken = false
                
                if (response.isSuccessful) {
                    try {
                        val responseBody = response.body?.string() ?: return
                        val jsonResponse = JSONObject(responseBody)
                        
                        // Server returns: { data: [{ token: "...", refreshToken: "..." }] }
                        // Same format as Flutter auto-login response
                        val dataArray = jsonResponse.optJSONArray("data")
                        val tokenData = if (dataArray != null && dataArray.length() > 0) {
                            dataArray.getJSONObject(0)
                        } else {
                            // Fallback: flat response { token: "...", refreshToken: "..." }
                            jsonResponse
                        }

                        val newAccessToken = tokenData.optString("token", "")
                        val newRefreshToken = tokenData.optString("refreshToken", "")

                        if (newAccessToken.isNotBlank() && newRefreshToken.isNotBlank()) {
                            tokenManager.saveTokens(newAccessToken, newRefreshToken)
                            Log.d(TAG, "Tokens refreshed successfully")
                            lastSyncStatus = "Retrying..."
                            updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                            sendToServer(lat, lon, timestamp)
                        } else {
                            Log.e(TAG, "Response missing token fields. Body: $responseBody")
                            lastSyncStatus = "Invalid response"
                            updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing refresh response: ${e.message}")
                        lastSyncStatus = "Parse error"
                        updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                    }
                } else if (response.code == 401 || response.code == 403) {
                    Log.e(TAG, "Refresh token expired or invalid (${response.code}). Shutting down service.")
                    
                    // Session is fully dead. Clear tokens so we don't try again.
                    tokenManager.clearTokens()
                    
                    // Clear geofences so we don't fire ghost alerts for a logged-out user
                    geofenceMonitor.clearAllZones()
                    
                    // Update notification one last time to tell the user they need to log in
                    lastSyncStatus = "Session expired. Open app to log in."
                    updateNotification(lastSyncStatus, "—", "—", "—")
                    
                    // Stop listening for GPS and kill the service
                    stopSelf()
                } else {
                    Log.e(TAG, "Token refresh failed: ${response.code}")
                    lastSyncStatus = "Refresh failed: ${response.code}"
                    updateNotification(lastSyncStatus, lastLocationLat, lastLocationLng, lastLocationTime)
                }
                
                response.close()
            }
        })
    }

    // ============ Geofence Monitoring ============

    private fun handleGeofenceUpdate(jsonStr: String) {
        if (jsonStr.isEmpty()) {
            Log.w(TAG, "Empty geofence JSON received")
            return
        }
        
        try {
            val json = JSONObject(jsonStr)
            val id = json.getString("id")
            val name = json.optString("name", "Geofence")
            val type = json.optString("type", "LOCAL")
            val pointsArray = json.getJSONArray("points")
            
            val points = mutableListOf<DoubleArray>()
            for (i in 0 until pointsArray.length()) {
                val point = pointsArray.getJSONArray(i)
                points.add(doubleArrayOf(point.getDouble(0), point.getDouble(1)))
            }
            
            geofenceMonitor.registerZone(id, name, type, points)
            Log.d(TAG, "Geofence updated: id=$id, name=$name, type=$type, points=${points.size}")
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing geofence JSON: ${e.message}")
        }
    }

    private fun checkGeofences(lat: Double, lng: Double) {
        if (!geofenceMonitor.hasZones()) return
        
        val events = geofenceMonitor.checkLocation(lat, lng)
        
        for (event in events) {
            when (event.eventType) {
                "EXIT" -> {
                    Log.d(TAG, "🚨 GEOFENCE EXIT: ${event.zoneName} (${event.zoneType})")
                    fireGeofenceAlert(
                        title = "${event.zoneType.lowercase().replaceFirstChar { it.uppercase() }} Fence Alert",
                        message = "You have EXITED the ${event.zoneName} zone!",
                        isExit = true
                    )
                    // For GROUP fences: also emit a fenceEvent via WebSocket so the admin is notified
                    if (event.zoneType == "GROUP") {
                        emitGroupFenceEvent(event.eventType, lat, lng)
                    }
                }
                "ENTER" -> {
                    Log.d(TAG, "✅ GEOFENCE ENTER: ${event.zoneName} (${event.zoneType})")
                    fireGeofenceAlert(
                        title = "${event.zoneType.lowercase().replaceFirstChar { it.uppercase() }} Fence Re-entry",
                        message = "You are back INSIDE the ${event.zoneName} safe zone.",
                        isExit = false
                    )
                    // For GROUP fences: also emit re-entry via WebSocket
                    if (event.zoneType == "GROUP") {
                        emitGroupFenceEvent(event.eventType, lat, lng)
                    }
                }
            }
        }
    }

    /**
     * Emit a `fenceEvent` via the background WebSocket connection.
     * If the socket is not yet connected (e.g. service just started), attempt to reconnect first.
     */
    private fun emitGroupFenceEvent(type: String, lat: Double, lng: Double) {
        try {
            if (socketManager == null) {
                Log.w(TAG, "SocketManager null — initialising before emit")
                initSocketManager()
            }
            socketManager?.emitFenceEvent(type, lat, lng)
            Log.d(TAG, "GROUP fenceEvent emitted via background socket: $type")
        } catch (e: Exception) {
            Log.e(TAG, "Error emitting group fenceEvent: ${e.message}")
        }
    }

    private fun fireGeofenceAlert(title: String, message: String, isExit: Boolean) {
        try {
            // Vibrate
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val pattern = if (isExit) {
                    longArrayOf(0, 500, 200, 500, 200, 500)
                } else {
                    longArrayOf(0, 300)
                }
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (isExit) 2000L else 300L)
            }
            
            // Show heads-up notification
            geofenceNotifCounter++
            val notifId = GEOFENCE_NOTIF_ID_BASE + geofenceNotifCounter
            
            val icon = if (isExit) android.R.drawable.ic_dialog_alert else android.R.drawable.ic_dialog_info
            val color = if (isExit) 0xFFFF5252.toInt() else 0xFF4CAF50.toInt()
            
            val notification = NotificationCompat.Builder(this, GEOFENCE_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(icon)
                .setColor(color)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_SOUND)
                .build()
            
            getSystemService(NotificationManager::class.java).notify(notifId, notification)
            Log.d(TAG, "Geofence alert fired: $title - $message")
        } catch (e: Exception) {
            Log.e(TAG, "Error firing geofence alert: ${e.message}")
        }
    }

    // ============ Notification Management ============

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Location Tracking",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Continuous location tracking"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            Log.d(TAG, "Notification channel created")
        }
    }

    private fun createGeofenceNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                GEOFENCE_CHANNEL_ID,
                "Geofence Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for geofence entry/exit events"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            Log.d(TAG, "Geofence notification channel created")
        }
    }

    private fun buildNotification(
        syncStatus: String,
        latitude: String,
        longitude: String,
        timestamp: String
    ): Notification {
        val contentText = syncStatus
        
        val bigText = """
            Latitude:  $latitude
            Longitude: $longitude
            Timestamp: $timestamp
            
            Status: $syncStatus
        """.trimIndent()
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Location Tracking")
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setOnlyAlertOnce(true)
            .setColor(0xFF1F6FEB.toInt())
            .build()
    }

    private fun updateNotification(
        syncStatus: String,
        latitude: String,
        longitude: String,
        timestamp: String
    ) {
        try {
            lastSyncStatus = syncStatus
            lastLocationLat = latitude
            lastLocationLng = longitude
            lastLocationTime = timestamp
            
            val notification = buildNotification(syncStatus, latitude, longitude, timestamp)
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification)
            Log.d(TAG, "Notification updated")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating notification: ${e.message}")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.d(TAG, "Service destroyed")
        try {
            locationManager.removeUpdates(locationListener)
            Log.d(TAG, "Location listener removed")
        } catch (e: Exception) {
            Log.e(TAG, "Error removing updates: ${e.message}")
        }
        // Stop background API sync
        try {
            backgroundSyncManager.stop()
            Log.d(TAG, "BackgroundSyncManager stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping BackgroundSyncManager: ${e.message}")
        }
        // Disconnect the background socket cleanly
        try {
            socketManager?.disconnect()
            socketManager = null
            Log.d(TAG, "SocketManagerService disconnected")
        } catch (e: Exception) {
            Log.e(TAG, "Error disconnecting socket: ${e.message}")
        }
        // Unregister network callback
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
            Log.d(TAG, "NetworkCallback unregistered")
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering NetworkCallback: ${e.message}")
        }
        // Force the notification to be dismissed when the service is killed
        stopForeground(true)
        super.onDestroy()
    }
}
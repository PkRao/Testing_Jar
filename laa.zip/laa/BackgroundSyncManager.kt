package com.bel.laa

import android.os.Handler
import android.os.Looper
import android.util.Log
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

/**
 * BackgroundSyncManager — an extensible, token-aware periodic API poller.
 *
 * Runs entirely on the main looper via [Handler.postDelayed] — no threads or
 * coroutines required.  A token is fetched once at the start of each cycle;
 * if it is expired the manager refreshes it before running any tasks.
 *
 * ── Registering tasks ────────────────────────────────────────────────────────
 *
 *   syncManager.register("fence_refresh") { token ->
 *       // make your HTTP call with `token`
 *       // parse the response
 *       // update local state (e.g. GeofenceMonitor)
 *   }
 *
 *   // Future example:
 *   syncManager.register("members_refresh") { token -> ... }
 *
 * ── Lifecycle ────────────────────────────────────────────────────────────────
 *
 *   syncManager.start(intervalMs = 2 * 60 * 1000L)   // in onCreate
 *   syncManager.stop()                                // in onDestroy
 *
 * ── Task contract ────────────────────────────────────────────────────────────
 *
 * A [SyncTask] receives a valid Bearer token string and is responsible for
 * its own HTTP call.  It may be called on the main thread, so heavy parsing
 * should be done inside OkHttp's async callback (onResponse runs on an I/O
 * thread automatically).
 *
 * Tasks must NOT throw; all exceptions should be caught internally.
 */
class BackgroundSyncManager(
    private val tokenManager: TokenManager,
    private val client: OkHttpClient
) {
    // ── Public type alias ────────────────────────────────────────────────────
    /** A sync task receives a valid access token and performs its own work. */
    fun interface SyncTask {
        fun execute(token: String)
    }

    companion object {
        private const val TAG = "BackgroundSyncManager"
    }

    // ── Internal state ───────────────────────────────────────────────────────
    private val handler   = Handler(Looper.getMainLooper())
    private val tasks     = LinkedHashMap<String, SyncTask>() // preserves insertion order
    private var intervalMs = 2 * 60 * 1000L  // default 2 minutes
    private var running   = false

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Register a named sync task.
     * If a task with [name] already exists it is replaced (idempotent).
     * Tasks are executed in registration order each cycle.
     */
    fun register(name: String, task: SyncTask) {
        tasks[name] = task
        Log.d(TAG, "Task registered: '$name' (total=${tasks.size})")
    }

    /**
     * Unregister a previously registered task by name.
     */
    fun unregister(name: String) {
        tasks.remove(name)
        Log.d(TAG, "Task unregistered: '$name'")
    }

    /**
     * Start the periodic sync loop.
     * An immediate first cycle fires after [initialDelayMs] (default 5 s to
     * let the service settle), then repeats every [intervalMs].
     *
     * @param intervalMs   How often to run all tasks (default 2 minutes).
     * @param initialDelayMs  Delay before the very first run (default 5 s).
     */
    fun start(
        intervalMs: Long    = 2 * 60 * 1000L,
        initialDelayMs: Long = 5_000L
    ) {
        if (running) {
            Log.w(TAG, "Already running — ignoring duplicate start()")
            return
        }
        this.intervalMs = intervalMs
        running = true
        Log.d(TAG, "Started — interval=${intervalMs / 1000}s, initial delay=${initialDelayMs / 1000}s, tasks=${tasks.size}")
        handler.postDelayed(cycleRunnable, initialDelayMs)
    }

    /**
     * Stop the periodic sync loop.  Safe to call multiple times.
     */
    fun stop() {
        running = false
        handler.removeCallbacks(cycleRunnable)
        Log.d(TAG, "Stopped")
    }

    // ── Internal cycle logic ─────────────────────────────────────────────────

    private val cycleRunnable = object : Runnable {
        override fun run() {
            if (!running) return

            Log.d(TAG, "▶ Sync cycle start (${tasks.size} tasks)")
            executeCycle()

            // Schedule the next cycle
            handler.postDelayed(this, intervalMs)
        }
    }

    /**
     * Fetch a valid token (refreshing if needed), then run every registered task.
     * If the refresh itself fails, the cycle is skipped — tasks won't be called
     * with a stale/null token.
     */
    private fun executeCycle() {
        val token = tokenManager.getValidAccessToken()

        if (token != null) {
            // Token is valid — run all tasks immediately
            runAllTasks(token)
        } else {
            // Token expired — attempt a background refresh first
            Log.d(TAG, "Token expired — refreshing before running tasks")
            refreshTokenThenRun()
        }
    }

    private fun runAllTasks(token: String) {
        for ((name, task) in tasks) {
            try {
                Log.d(TAG, "  ↳ running task: '$name'")
                task.execute(token)
            } catch (e: Exception) {
                Log.e(TAG, "  ✗ task '$name' threw an exception: ${e.message}")
            }
        }
    }

    private fun refreshTokenThenRun() {
        val refreshToken = tokenManager.getRefreshToken()
        if (refreshToken.isNullOrBlank()) {
            Log.w(TAG, "No refresh token available — skipping cycle")
            return
        }

        val body = JSONObject()
            .apply { put("refreshToken", refreshToken) }
            .toString()
            .toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(AppConfig.getRefreshTokenUrl())
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Token refresh failed during sync cycle: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    if (!resp.isSuccessful) {
                        Log.w(TAG, "Token refresh returned ${resp.code} — skipping cycle")
                        return
                    }
                    try {
                        val json   = JSONObject(resp.body?.string() ?: return)
                        val data   = json.optJSONArray("data")
                        val tokenObj = if (data != null && data.length() > 0)
                            data.getJSONObject(0) else json

                        val newAccess  = tokenObj.optString("token", "")
                        val newRefresh = tokenObj.optString("refreshToken", "")

                        if (newAccess.isNotBlank() && newRefresh.isNotBlank()) {
                            tokenManager.saveTokens(newAccess, newRefresh)
                            Log.d(TAG, "Token refreshed — running ${tasks.size} tasks")
                            // Callback is on OkHttp I/O thread; post tasks back to main
                            handler.post { runAllTasks(newAccess) }
                        } else {
                            Log.w(TAG, "Refresh response missing token fields — skipping cycle")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing refresh response: ${e.message}")
                    }
                }
            }
        })
    }
}

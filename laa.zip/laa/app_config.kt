package com.bel.laa

object AppConfig {
    // Base URLs
    //const val API_BASE_URL = "https://34.47.241.156:3001/api"
    //const val SOCKET_URL = "https://34.47.241.156:3001"
    //const val GEOSERVER_URL = "https://34.47.241.156:8443"

    //const val API_BASE_URL = "https://laa.bel.tcs:3001/api"
    //const val SOCKET_URL = "https://laa.bel.tcs:3001"
    //const val GEOSERVER_URL = "https://gis.bel.tcs:8443"











//    const val API_BASE_URL = "https://172.195.133.6:3001/api" //replacement
//    const val API_BASE_URL = "http://localhost:8085"
    const val API_BASE_URL = "http://172.26.223.118:8085"

//    const val SOCKET_URL = "https://172.195.133.6:3001"
    const val SOCKET_URL = "http://172.26.223.118:8085"
    const val GEOSERVER_URL = "https://172.195.133.6:8443"













    // API Endpoints
//    const val ENDPOINT_ADD_LOCATION = "/users/add_location"//old
    const val ENDPOINT_ADD_LOCATION = "/nodeService/api/location/users"
    const val ENDPOINT_REFRESH_TOKEN = "/users/refresh"
//    const val ENDPOINT_FENCE_LIST    = "/gis/fence_list"//old
    const val ENDPOINT_FENCE_LIST    = "/locationService/api/fence/list"

    // complete URLs
    fun getLocationUrl(): String    = "$API_BASE_URL$ENDPOINT_ADD_LOCATION"
    fun getRefreshTokenUrl(): String = "$API_BASE_URL$ENDPOINT_REFRESH_TOKEN"
    fun getFenceListUrl(): String   = "$API_BASE_URL$ENDPOINT_FENCE_LIST"
}
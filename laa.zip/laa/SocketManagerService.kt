package com.bel.laa

import android.content.Context
import android.util.Log
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * SocketManagerService — A lightweight Socket.IO v2/v4 client for background use.
 *
 * Uses OkHttp WebSocket (already a dependency) with manual Socket.IO framing:
 *   - Outgoing events: `42["eventName", {...}]`
 *   - Incoming events: `42["eventName", {...}]`
 *
 * This runs inside the native LocationService and keeps a persistent connection
 * alive even when the Flutter app is killed. It handles:
 *   - Registering the user with the server (userId + role)
 *   - Emitting `fenceEvent` when a GROUP geofence violation is detected
 *   - Listening for `groupNotification` and calling back into LocationService
 *   - Auto-reconnection with exponential back-off
 *
 * NOTE: Socket.IO also sends non-event frames (0=open, 1=close, 40=connect, 41=disconnect,
 * 2=ping, 3=pong). We handle the minimal subset needed for reliable communication.
 */
class SocketManagerService(
    private val context: Context,
    private val onGroupNotification: (String) -> Unit   // callback → LocationService shows notification
)
{
    companion object {
        private const val TAG = "SocketMgr"
        private const val PREFS_NAME = "com.bel.laa.userinfo"
        // No hard attempt cap — we keep retrying so a network switch (same URL,
        // new DNS-resolved IP) will eventually succeed.
        private const val RECONNECT_BASE_DELAY_MS = 2000L
        private const val RECONNECT_MAX_DELAY_MS  = 15000L  // cap backoff at 15s
    }

    // ============ State ============
    private var webSocket: WebSocket? = null
    private var isConnected = false
    private var isConnecting = false
    private var reconnectAttempts = 0
    private var isShuttingDown = false
    private var reconnectRunnable: Runnable? = null
    private val reconnectHandler = android.os.Handler(android.os.Looper.getMainLooper())

    // User identity read from SharedPreferences
    private val userPrefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private val userId: String get() = userPrefs.getString("userId", "") ?: ""
    private val role: String get() = userPrefs.getString("role", "") ?: ""
    private val serviceId: String get() = userPrefs.getString("serviceId", "") ?: ""

    // ============ OkHttp client that trusts all SSL certs (same as LocationService) ============
    private val httpClient: OkHttpClient by lazy {
        createUnsafeOkHttpClient()
    }

    private fun createUnsafeOkHttpClient(): OkHttpClient {
        return try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())

            OkHttpClient.Builder()
                .sslSocketFactory(sslContext.socketFactory, trustAllCerts[0] as X509TrustManager)
                .hostnameVerifier { _, _ -> true }
                .pingInterval(25, TimeUnit.SECONDS)   // keep-alive pings
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.SECONDS)      // never timeout on read (persistent connection)
                .writeTimeout(20, TimeUnit.SECONDS)
                .build()
        } catch (e: Exception) {
            Log.e(TAG, "Error creating OkHttpClient: ${e.message}")
            OkHttpClient()
        }
    }

    // ============ Public API ============

    /**
     * Connect to the Socket.IO server. Safe to call multiple times — will no-op if already
     * connected or if userId/role are not yet stored.
     */
    fun connect() {
        if (isShuttingDown) return
        if (isConnected || isConnecting) {
            Log.d(TAG, "Already connected/connecting — skipping")
            return
        }

        val uid = userId
        val r = role

        if (uid.isBlank() || r.isBlank()) {
            Log.w(TAG, "userId or role not available — skipping socket connect")
            return
        }

        isConnecting = true
        Log.d(TAG, "Connecting to socket: $uid @ $r")

        // Socket.IO v2 WebSocket URL:  wss://host/socket.io/?EIO=3&transport=websocket
        // Socket.IO v4 uses EIO=4. Try v4 first; the server decides.
        val socketUrl = buildSocketUrl()

        val request = Request.Builder()
            .url(socketUrl)
            .build()

        webSocket = httpClient.newWebSocket(request, socketListener)
    }

    /**
     * Emit a `fenceEvent` to the server. Only called for GROUP-type geofence violations.
     * The server then routes a `groupNotification` to the admin socket.
     */
    fun emitFenceEvent(type: String, lat: Double, lng: Double) {
        val uid = userId
        val sid = serviceId

        if (uid.isBlank()) {
            Log.w(TAG, "emitFenceEvent: userId empty — cannot emit")
            return
        }

        val payload = JSONObject().apply {
            put("userId", uid)
            put("type", type)           // "EXIT" or "ENTER"
            put("latitude", lat)
            put("longitude", lng)
            put("service_id", sid)
        }

        sendSocketEvent("fenceEvent", payload)
        Log.d(TAG, "fenceEvent emitted: type=$type, lat=$lat, lng=$lng, userId=$uid")
    }

    /**
     * Force an immediate reconnect. Called when the device switches to a new
     * network — same domain `laa.bel.tcs` resolves to a different server IP,
     * so we tear down the dead socket and open a fresh one to get a new DNS
     * lookup automatically.
     */
    fun forceReconnect() {
        Log.d(TAG, "forceReconnect() called — tearing down existing socket")
        cancelReconnect()
        webSocket?.close(1000, "Network change")
        webSocket = null
        isConnected = false
        isConnecting = false
        reconnectAttempts = 0   // reset backoff counter for the new network

        // Short delay to let the new network interface settle before DNS lookup
        reconnectHandler.postDelayed({
            if (!isShuttingDown) {
                Log.d(TAG, "forceReconnect: connecting after network settle delay")
                connect()
            }
        }, 1500L)
    }

    /**
     * Gracefully disconnect. Called from LocationService.onDestroy().
     */
    fun disconnect() {
        isShuttingDown = true
        cancelReconnect()
        webSocket?.close(1000, "Service stopped")
        webSocket = null
        isConnected = false
        isConnecting = false
        Log.d(TAG, "Socket disconnected (service stop)")
    }

    // ============ Socket.IO Framing ============

    /**
     * Send a Socket.IO event frame: `42["eventName", {...}]`
     */
    private fun sendSocketEvent(eventName: String, payload: JSONObject) {
        if (!isConnected || webSocket == null) {
            Log.w(TAG, "Cannot send '$eventName' — not connected")
            return
        }

        try {
            val arr = JSONArray().apply {
                put(eventName)
                put(payload)
            }
            val frame = "42$arr"
            webSocket?.send(frame)
            Log.d(TAG, "Sent: $frame")
        } catch (e: Exception) {
            Log.e(TAG, "Error sending socket event '$eventName': ${e.message}")
        }
    }

    /**
     * Send a Socket.IO PING (frame type 2). The server responds with PONG (3).
     * OkHttp's built-in WS ping is at TCP level; Socket.IO uses application-level pings too.
     */
    private fun sendSocketPing() {
        webSocket?.send("2")
    }

    /**
     * Parse an incoming Socket.IO text frame and dispatch to appropriate handler.
     *
     * Socket.IO v2/v4 text packet types:
     *   0  = ENGINE_OPEN       (initial handshake from engine.io)
     *   1  = ENGINE_CLOSE
     *   2  = ENGINE_PING
     *   3  = ENGINE_PONG
     *   40 = SOCKET_CONNECT    (namespace connect confirmation)
     *   41 = SOCKET_DISCONNECT
     *   42 = SOCKET_EVENT      — what we care about for fenceEvent/groupNotification
     *   43 = SOCKET_ACK
     */
    private fun handleFrame(text: String) {
        Log.v(TAG, "Received frame: ${text.take(200)}")

        when {
            text.startsWith("0") -> {
                // ENGINE_OPEN — server sends its session details
                // We respond with a Socket.IO namespace connect: "40"
                Log.d(TAG, "ENGINE_OPEN received — sending namespace connect")
                webSocket?.send("40")
            }

            text == "2" -> {
                // ENGINE_PING — respond with PONG
                webSocket?.send("3")
            }

            text.startsWith("40") -> {
                // SOCKET_CONNECT — namespace connect confirmed
                Log.d(TAG, "Socket.IO namespace connected")
                isConnected = true
                isConnecting = false
                reconnectAttempts = 0  // reset so next disconnect starts backoff from scratch

                // Register user with the server
                registerUser()
            }

            text.startsWith("42") -> {
                // SOCKET_EVENT — parse and dispatch
                try {
                    val jsonStr = text.substring(2) // strip the "42" prefix
                    val arr = JSONArray(jsonStr)
                    val eventName = arr.getString(0)
                    val payload = if (arr.length() > 1) arr.getJSONObject(1) else JSONObject()

                    handleSocketEvent(eventName, payload)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing socket event: ${e.message} | raw: ${text.take(200)}")
                }
            }

            text.startsWith("41") -> {
                // SOCKET_DISCONNECT — server closed the namespace
                Log.w(TAG, "Socket.IO namespace disconnected by server")
                isConnected = false
            }

            else -> {
                Log.v(TAG, "Unhandled frame type: ${text.take(20)}")
            }
        }
    }

    /**
     * Dispatch a parsed Socket.IO event to the appropriate handler.
     */
    private fun handleSocketEvent(eventName: String, payload: JSONObject) {
        Log.d(TAG, "Socket event: $eventName, payload: ${payload.toString().take(200)}")

        when (eventName) {
            "groupNotification" -> {
                val message = payload.optString("message", "Geofence alert")
                Log.d(TAG, "🔔 groupNotification received: $message")
                onGroupNotification(message)
            }

            "registered" -> {
                Log.d(TAG, "✅ User registered successfully")
            }

            else -> {
                Log.d(TAG, "Unhandled event: $eventName")
            }
        }
    }

    /**
     * Emit `register` with userId + role, just like Flutter's SocketService does.
     */
    private fun registerUser() {
        val uid = userId
        val r = role

        if (uid.isBlank() || r.isBlank()) {
            Log.w(TAG, "registerUser: userId or role empty")
            return
        }

        val payload = JSONObject().apply {
            put("userId", uid)
            put("role", r)
        }

        sendSocketEvent("register", payload)
        Log.d(TAG, "Registered: userId=$uid, role=$r")
    }

    // ============ WebSocket Listener ============

    private val socketListener = object : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d(TAG, "WebSocket opened: ${response.code}")
            // Do NOT set isConnected here — wait for Socket.IO "40" (namespace connect)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleFrame(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
            Log.d(TAG, "Binary frame received (ignored): ${bytes.size} bytes")
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WebSocket closing: code=$code, reason=$reason")
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WebSocket closed: code=$code, reason=$reason")
            isConnected = false
            isConnecting = false

            if (!isShuttingDown) {
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WebSocket failure: ${t.message}")
            isConnected = false
            isConnecting = false

            if (!isShuttingDown) {
                scheduleReconnect()
            }
        }
    }

    // ============ Reconnection Logic ============

    private fun scheduleReconnect() {
        cancelReconnect()
        reconnectAttempts++

        // Exponential backoff capped at RECONNECT_MAX_DELAY_MS — keep retrying
        // indefinitely so a network switch (same URL, new IP) will reconnect.
        val delayMs = minOf(
            RECONNECT_BASE_DELAY_MS * (1L shl (reconnectAttempts - 1).coerceAtMost(10)),
            RECONNECT_MAX_DELAY_MS
        )

        Log.d(TAG, "Reconnecting in ${delayMs}ms (attempt $reconnectAttempts, no cap)")

        reconnectRunnable = Runnable {
            if (!isShuttingDown) {
                Log.d(TAG, "Attempting reconnect #$reconnectAttempts...")
                webSocket = null
                isConnecting = false
                connect()
            }
        }

        reconnectHandler.postDelayed(reconnectRunnable!!, delayMs)
    }

    private fun cancelReconnect() {
        reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }
        reconnectRunnable = null
    }

    // ============ URL Builder ============

    /**
     * Build the Socket.IO WebSocket URL from AppConfig.SOCKET_URL.
     * Converts https:// → wss:// and appends Socket.IO query params.
     */
    private fun buildSocketUrl(): String {
        val base = AppConfig.SOCKET_URL
            .replace("https://", "wss://")
            .replace("http://", "ws://")
            .trimEnd('/')
//        wss://172.195.133.6:3001/socket.io/?EIO=4&transport=websocket
//        return "$base/socket.io/?EIO=4&transport=websocket"
        return "$base/notificationService/wsConnect"
    }
}

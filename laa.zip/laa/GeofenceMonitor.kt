package com.bel.laa

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

/**
 * GeofenceMonitor — An extensible engine for monitoring multiple geofence zones.
 *
 * Supports multiple zone types (LOCAL, GROUP, etc.) and tracks entry/exit
 * state independently for each zone. Uses the ray-casting point-in-polygon
 * algorithm (same logic as turf.booleanPointInPolygon used in Flutter).
 *
 * Zone data is persisted to SharedPreferences so it survives service restarts
 * (e.g., when the app is cleared from recent apps).
 *
 * Usage:
 *   val monitor = GeofenceMonitor(context)
 *   monitor.registerZone("fence_1", "My Local Fence", "LOCAL", listOf(
 *       doubleArrayOf(lat1, lng1), doubleArrayOf(lat2, lng2), ...
 *   ))
 *   val events = monitor.checkLocation(currentLat, currentLng)
 *   // events contains GeofenceEvent objects for any state transitions
 */
class GeofenceMonitor(context: Context) {

    companion object {
        private const val TAG = "GeofenceMonitor"
        private const val PREFS_NAME = "com.bel.laa.geofences"
        private const val KEY_ZONES = "zones_json"
    }

    /**
     * Represents a single geofence zone.
     * @param id Unique identifier for this zone
     * @param name Human-readable name (shown in notifications)
     * @param type Zone type: "LOCAL", "GROUP", or any future type
     * @param points List of [lat, lng] pairs forming the polygon boundary
     * @param hasExited Tracks whether the user is currently outside this zone
     */
    data class GeofenceZone(
        val id: String,
        val name: String,
        val type: String,
        val points: List<DoubleArray>,
        var hasExited: Boolean = false
    )

    /**
     * Represents a geofence state transition event.
     * @param zoneId The zone that triggered the event
     * @param zoneName Human-readable name
     * @param zoneType "LOCAL", "GROUP", etc.
     * @param eventType "EXIT" or "ENTER"
     */
    data class GeofenceEvent(
        val zoneId: String,
        val zoneName: String,
        val zoneType: String,
        val eventType: String  // "EXIT" or "ENTER"
    )

    private val zones = mutableMapOf<String, GeofenceZone>()
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    init {
        // Load persisted zones on creation (survives service restarts)
        loadFromPrefs()
    }

    /**
     * Register or update a geofence zone.
     * If a zone with the same ID already exists, it will be replaced
     * and its exit state will be reset. Persists to disk.
     */
    fun registerZone(id: String, name: String, type: String, points: List<DoubleArray>) {
        if (points.size < 3) {
            Log.w(TAG, "Cannot register zone '$name': needs at least 3 points, got ${points.size}")
            return
        }
        zones[id] = GeofenceZone(id, name, type, points)
        Log.d(TAG, "Registered zone: id=$id, name=$name, type=$type, points=${points.size}")
        saveToPrefs()
    }

    /**
     * Remove a specific zone by ID. Persists to disk.
     */
    fun removeZone(id: String) {
        zones.remove(id)
        Log.d(TAG, "Removed zone: $id")
        saveToPrefs()
    }

    /**
     * Remove all zones of a specific type (e.g., "LOCAL" or "GROUP"). Persists to disk.
     */
    fun removeZonesByType(type: String) {
        val toRemove = zones.filter { it.value.type == type }.keys
        toRemove.forEach { zones.remove(it) }
        Log.d(TAG, "Removed ${toRemove.size} zones of type $type")
        saveToPrefs()
    }

    /**
     * Clear all registered zones. Called during logout / user switch. Persists to disk.
     */
    fun clearAllZones() {
        zones.clear()
        Log.d(TAG, "All geofence zones cleared")
        saveToPrefs()
    }

    /**
     * Check if any registered zones have been entered or exited.
     * Returns a list of GeofenceEvent for each state transition detected.
     */
    fun checkLocation(lat: Double, lng: Double): List<GeofenceEvent> {
        val events = mutableListOf<GeofenceEvent>()

        for ((_, zone) in zones) {
            if (zone.points.size < 3) continue

            val isInside = isPointInPolygon(lat, lng, zone.points)

            if (!isInside && !zone.hasExited) {
                // Just exited
                zone.hasExited = true
                events.add(GeofenceEvent(zone.id, zone.name, zone.type, "EXIT"))
                Log.d(TAG, "EXIT detected: zone=${zone.name}, type=${zone.type}")
            } else if (isInside && zone.hasExited) {
                // Just re-entered
                zone.hasExited = false
                events.add(GeofenceEvent(zone.id, zone.name, zone.type, "ENTER"))
                Log.d(TAG, "ENTER detected: zone=${zone.name}, type=${zone.type}")
            }
        }

        return events
    }

    /**
     * Returns true if there are any registered zones.
     */
    fun hasZones(): Boolean = zones.isNotEmpty()

    /**
     * Returns the count of registered zones.
     */
    fun zoneCount(): Int = zones.size

    // ============ Persistence (SharedPreferences) ============

    private fun saveToPrefs() {
        try {
            val zonesArray = JSONArray()
            for ((_, zone) in zones) {
                val zoneObj = JSONObject().apply {
                    put("id", zone.id)
                    put("name", zone.name)
                    put("type", zone.type)
                    val pointsArr = JSONArray()
                    for (point in zone.points) {
                        val p = JSONArray()
                        p.put(point[0]) // lat
                        p.put(point[1]) // lng
                        pointsArr.put(p)
                    }
                    put("points", pointsArr)
                }
                zonesArray.put(zoneObj)
            }
            prefs.edit().putString(KEY_ZONES, zonesArray.toString()).apply()
            Log.d(TAG, "Saved ${zones.size} zones to SharedPreferences")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving zones to prefs: ${e.message}")
        }
    }

    private fun loadFromPrefs() {
        try {
            val jsonStr = prefs.getString(KEY_ZONES, null) ?: return
            val zonesArray = JSONArray(jsonStr)

            for (i in 0 until zonesArray.length()) {
                val zoneObj = zonesArray.getJSONObject(i)
                val id = zoneObj.getString("id")
                val name = zoneObj.optString("name", "Geofence")
                val type = zoneObj.optString("type", "LOCAL")
                val pointsArr = zoneObj.getJSONArray("points")

                val points = mutableListOf<DoubleArray>()
                for (j in 0 until pointsArr.length()) {
                    val p = pointsArr.getJSONArray(j)
                    points.add(doubleArrayOf(p.getDouble(0), p.getDouble(1)))
                }

                if (points.size >= 3) {
                    zones[id] = GeofenceZone(id, name, type, points)
                }
            }
            Log.d(TAG, "Loaded ${zones.size} zones from SharedPreferences")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading zones from prefs: ${e.message}")
        }
    }

    // ============ Ray-Casting Point-in-Polygon Algorithm ============
    // This is the same algorithm used by turf.booleanPointInPolygon in Flutter.
    // It casts a horizontal ray from the point and counts how many times it
    // crosses polygon edges. Odd = inside, Even = outside.

    private fun isPointInPolygon(lat: Double, lng: Double, polygon: List<DoubleArray>): Boolean {
        var inside = false
        val n = polygon.size
        var j = n - 1

        for (i in 0 until n) {
            val yi = polygon[i][0] // latitude
            val xi = polygon[i][1] // longitude
            val yj = polygon[j][0]
            val xj = polygon[j][1]

            val intersect = ((yi > lat) != (yj > lat)) &&
                    (lng < (xj - xi) * (lat - yi) / (yj - yi) + xi)

            if (intersect) {
                inside = !inside
            }

            j = i
        }

        return inside
    }
}

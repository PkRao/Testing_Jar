package org.bel.locationService.dto.request;

import jakarta.persistence.*;
import java.time.*;

@Entity
@Table(name="version")
public class Version {

 @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "id")
   private Integer id;

   @Column(name = "version_number")
   private String versionNumber;

   @Column(name = "features")
   private String features;

   @Column(name = "build_number")
   private String buildNumber;

   @Column(name = "created_at")
   private LocalDate createdAt;

}

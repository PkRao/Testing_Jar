package org.bel.locationService.exception;

public class UnauthorisedException extends RuntimeException {

	public UnauthorisedException(String message) {
		super(message);
	}
}

package org.bel.locationService.dto.request;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LocationHistoryRequest {
	
	@NotNull(message = "User id is required")
	private Integer userId;
	
	@NotNull(message = "From Date and time is required")
    @JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss")
	private LocalDateTime fromDateAndTime;
	
	@NotNull(message = "To Date and time is required")
    @JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss")
	private LocalDateTime toDateAndTime;
}

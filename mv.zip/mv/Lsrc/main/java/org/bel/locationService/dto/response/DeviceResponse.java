package org.bel.locationService.dto.response;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DeviceResponse {
	private Integer mdmUeId;
	private String deviceId;
	private String deviceName;
	
}

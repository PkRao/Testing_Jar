package org.bel.locationService.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.bel.locationService.dto.response.FencingBoundaryResponse;
import org.bel.locationService.dto.response.FencingListResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.entity.LaaGisFencing;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGisFencingRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.service.GisService;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class GisServiceImpl implements GisService{

	private final LaaGisFencingRepository fencingRepository;
	private final MdmUserRepository userRepository;
	private final ObjectMapper objectMapper;
	
	@Override
	public SingleResponse<?> getFencingList(Integer mdmUserId) {
		
		MdmUser user = userRepository.findById(mdmUserId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
		
		List<LaaGisFencing> fencingList = fencingRepository.findByMdmUserOrderByCreatedAtAsc(user)
				.orElseThrow(() -> new CustomException(CustomStatus.FAILURE, 404));
		
		List<FencingListResponse> response = fencingList.stream()
				.map(fence -> {
					FencingListResponse fenceResponse = new FencingListResponse();
					fenceResponse.setId(fence.getId());
					fenceResponse.setFenceName(fence.getFenceName());
					fenceResponse.setFenceStatus(fence.getFenceStatus());
					fenceResponse.setMdmRoleId(fence.getMdmUser().getMdmRole().getId());
					fenceResponse.setMdmUserId(fence.getMdmUser().getId());
					 if (fence.getFencingBoundary() != null && !fence.getFencingBoundary().toString().isEmpty()) {
	                        try {
	                            // 1. Parse the DB String into a generic JsonNode (which represents the whole JSON structure)
	                            JsonNode rootNode = objectMapper.readTree(fence.getFencingBoundary());
	                            
	                            // 2. Check if it's an array (it should be based on your DB data)
	                            if (rootNode.isArray()) {
	                                List<FencingBoundaryResponse> points = new ArrayList<>();
	                                
	                                for (JsonNode pointNode : rootNode) {
	                                    // Each pointNode is an array like [13.0, 77.5]
	                                    if (pointNode.isArray() && pointNode.size() == 2) {
	                                        double lat = pointNode.get(0).asDouble();
	                                        double lon = pointNode.get(1).asDouble();
	                                        
	                                        // Create the object manually
	                                        FencingBoundaryResponse point = new FencingBoundaryResponse(lat, lon);
	                                        points.add(point);
	                                    }
	                                }
	                                fenceResponse.setFencingBoundary(points);
	                            }
	                        } catch (Exception e) {
	                            throw new RuntimeException("Error parsing fencing boundary", e);
	                        }
	                    }
					
					return fenceResponse;
				}).toList();
		return new SingleResponse<>(response, CustomStatus.SUCCESS)	;
	}

}

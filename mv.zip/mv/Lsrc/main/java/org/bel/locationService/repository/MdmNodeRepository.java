package org.bel.locationService.repository;

import org.bel.locationService.entity.MdmNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmNodeRepository extends JpaRepository<MdmNode, Integer>{

}

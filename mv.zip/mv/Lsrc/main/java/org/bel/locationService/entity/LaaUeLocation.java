package org.bel.locationService.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "laa_ue_location")
public class LaaUeLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mdm_user__id", referencedColumnName = "id")
    private MdmUser mdmUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mdm_ue__id", referencedColumnName = "id")
    private MdmUe mdmUe;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mdm_node__id", referencedColumnName = "id")
    private MdmNode mdmNode;

    @Column(name = "latitude", nullable = false, precision = 9, scale = 6)
    private BigDecimal latitude;

    @Column(name = "longitude", nullable = false, precision = 9, scale = 6)
    private BigDecimal longitude;

    @Column(name = "ue_status", nullable = false, length = 20)
    private String ueStatus;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDate createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDate updatedAt;

}

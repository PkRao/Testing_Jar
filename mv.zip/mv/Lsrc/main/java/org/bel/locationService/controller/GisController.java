package org.bel.locationService.controller;

import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.service.GisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/fence")
@RequiredArgsConstructor
public class GisController {
	
	private final GisService gisService;
	
	@GetMapping("/list")
	public ResponseEntity<SingleResponse<?>> getFencinglist(@RequestParam("userId") Integer mdmUserId){
		return ResponseEntity.ok(gisService.getFencingList(mdmUserId));
	}
}

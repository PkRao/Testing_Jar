package org.bel.locationService.generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PostgresEntityGenerator {
	private static final String DB_URL = "jdbc:postgresql://localhost:5432/tcs_backup1";

	private static final String DB_USER = "postgres";

	private static final String DB_PASSWORD = "root";

	private static final String PACKAGE_NAME = "or.bel.locationService.entity";

	private static final String OUTPUT_DIRECTORY = "src/main/java/org/bel/locationService/entity";

	private static final String DB_SCHEMA = "tcs_laa";

	public static void main(String args[]) {
		File outputDir = new File(OUTPUT_DIRECTORY);

		if (!outputDir.exists()) {
			outputDir.mkdirs();
		}

		try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {

			System.out.println("Connected to Postgresql");

			DatabaseMetaData metaData = connection.getMetaData();

			generateEntities(connection, metaData);

			System.out.println();
			System.out.println("Entity generation completed");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Database connection failed");
		}

	}

	private static void generateEntities(Connection connection, DatabaseMetaData metaData) throws SQLException {
		try (ResultSet tables = metaData.getTables(connection.getCatalog(), DB_SCHEMA, "%", new String[] { "TABLE" })) {
			while (tables.next()) {
				String tableName = tables.getString("TABLE_NAME");
				System.out.println("Generating entity for: " + tableName);

				generateEntity(metaData, tableName);
			}
		}
	}

	    private static void generateEntity(DatabaseMetaData metaData, String tableName) throws SQLException {
        String className = toPascalCase(tableName);
        Set<String> primaryKeys = getPrimaryKeys(metaData, tableName);

        List<ColumnInfo> columns = new ArrayList<>();

        try (ResultSet rs = metaData.getColumns(null, DB_SCHEMA, tableName, "%")) {
            while (rs.next()) {
                ColumnInfo column = new ColumnInfo();
                
                column.name = rs.getString("COLUMN_NAME");
                column.nullable = rs.getInt("NULLABLE");
                column.primaryKey = primaryKeys.contains(column.name);
                
                // Get the raw data from the driver
                int sqlType = rs.getInt("DATA_TYPE");
                String sqlTypeName = rs.getString("TYPE_NAME");
                
                System.out.println("Column: " + column.name + " | SQL Type Code: " + sqlType + " | SQL Type Name: " + sqlTypeName);

                // Let the logic decide the Java type based on the DB metadata
                column.javaType = determineJavaType(sqlType, sqlTypeName);
                
                columns.add(column);
            }
        }
        
        writeEntityFile(tableName, className, columns);
    }
    
    private static String determineJavaType(int sqlType, String sqlTypeName) {
        String lowerTypeName = sqlTypeName != null ? sqlTypeName.toLowerCase() : "";

        // 1. Postgres Extensions (String Check)
        if (lowerTypeName.contains("json") || lowerTypeName.contains("jsonb")) return "String";
        if (lowerTypeName.contains("geometry") || lowerTypeName.contains("geography")) return "String";
        if ("uuid".equals(lowerTypeName)) return "String";

        // 2. Standard JDBC Constants (No Hardcoding of Numbers)
        return switch (sqlType) {
            case Types.BIGINT -> "Long";
            case Types.INTEGER -> "Integer";
            case Types.SMALLINT -> "Short";
            case Types.BOOLEAN, Types.BIT -> "Boolean";
            case Types.DECIMAL, Types.NUMERIC -> "BigDecimal";
            case Types.DATE -> "LocalDate";
            case Types.TIME -> "LocalTime";
            case Types.TIMESTAMP, Types.TIMESTAMP_WITH_TIMEZONE -> "LocalDateTime";
            case Types.VARCHAR, Types.CHAR, Types.CLOB, Types.LONGVARCHAR, Types.LONGNVARCHAR -> "String";
            case Types.BINARY, Types.VARBINARY, Types.LONGVARBINARY, Types.BLOB -> "byte[]";
            default -> "String";
        };
    }


//	private static void generateEntity(DatabaseMetaData metaData, String tableName) throws SQLException{
//		String className = toPascalCase(tableName);
//		
//		Set<String> primaryKeys = getPrimaryKeys(metaData, tableName);
//		
//		List<ColumnInfo> columns = new ArrayList<>();
//		
//		try(ResultSet rs = metaData.getColumns(null, DB_SCHEMA, tableName, "%")) {
//			while(rs.next()) {
//				ColumnInfo column = new ColumnInfo();
//				
//				column.name = rs.getString("COLUMN_NAME");
//				
//				column.sqlType = rs.getInt("DATA_TYPE");
//				
//				column.typeName = rs.getString("TYPE_NAME");
//				
//				column.nullable = rs.getInt("NULLABLE");
//				
//				column.primaryKey = primaryKeys.contains(column.name);
//				
//				columns.add(column);
//			}
//		}
//		
//		writeEntityFile(tableName, className, columns);
//	}
//	
	private static Set<String> getPrimaryKeys(DatabaseMetaData metaData, String tableName) throws SQLException {
		Set<String> keys = new HashSet<>();

		try (ResultSet rs = metaData.getPrimaryKeys(null, DB_SCHEMA, tableName)) {
			while (rs.next()) {
				keys.add(rs.getString("COLUMN_NAME"));
			}
		}

		return keys;
	}

	private static void writeEntityFile(String tableName, String className, List<ColumnInfo> columns) {
		File file = new File(OUTPUT_DIRECTORY + "/" + className + ".java");

		try (FileWriter writer = new FileWriter(file)) {
			writer.write("package " + PACKAGE_NAME + ";\n\n");

			writer.write("import jakarta.persistence.*;\n");

			writer.write("import java.time.*;\n");

			writer.write("import java.math.BigDecimal;\n\n");

			writer.write("@Entity\n");

			writer.write("@Table(name=\"" + tableName + "\")\n");

			writer.write("public class " + className + " {\n\n");

			for (ColumnInfo column : columns) {
				String javaType = sqlTypeToJavaType(column.sqlType, column.typeName);

				if (column.primaryKey) {
					writer.write(" @Id\n");

					writer.write("   @GeneratedValue(strategy = GenerationType.IDENTITY)\n");
				}

				writer.write("   @Column(name = \"" + column.name + "\")\n");

				writer.write("   private " + javaType + " " + toCamelCase(column.name) + ";\n\n");
			}

			writer.write("}\n");

			System.out.println("Created: " + file.getPath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static String sqlTypeToJavaType(int sqlType, String typeName) {
		return switch (sqlType) {
		case Types.BIGINT -> "Long";
		case Types.INTEGER -> "Integer";
		case Types.SMALLINT -> "Short";
		case Types.BOOLEAN -> "Boolean";
		case Types.DECIMAL, Types.NUMERIC -> "BigDecimal";
		case Types.REAL, Types.FLOAT -> "Float";
		case Types.DOUBLE -> "Double";
		case Types.DATE -> "LocalDate";
		case Types.TIMESTAMP, Types.TIMESTAMP_WITH_TIMEZONE -> "LocalDateTime";
		case Types.TIME -> "LocalTime";
		case Types.VARCHAR, Types.CHAR, Types.LONGNVARCHAR -> "String";
		case Types.BINARY, Types.VARBINARY, Types.LONGVARBINARY -> "byte[]";

		default -> "String";
		};
	}

	private static String toPascalCase(String value) {
		StringBuilder result = new StringBuilder();

		boolean upper = true;

		for (char c : value.toCharArray()) {
			if (c == '_') {
				upper = true;
			} else {
				if (upper) {
					result.append(Character.toUpperCase(c));
					upper = false;
				} else {
					result.append(c);
				}
			}
		}
		return result.toString();
	}

	private static String toCamelCase(String value) {
		String pascal = toPascalCase(value);

		return Character.toLowerCase(pascal.charAt(0)) + pascal.substring(1);
	}

	private static class ColumnInfo {
		String name;
		int sqlType;
		String typeName;
		int nullable;
		boolean primaryKey;
		String javaType;
	}
}

package org.bel.locationService.dto.response;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MdmUserResponse {
	private Integer userId;
	private String userName;
	private String serviceId;
	private Integer roleId;
	private String roleName;
	private String userType;
	private DeviceResponse deviceResponse;
	
}

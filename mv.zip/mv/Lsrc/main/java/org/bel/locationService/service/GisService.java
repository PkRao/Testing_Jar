package org.bel.locationService.service;

import org.bel.locationService.dto.response.SingleResponse;

public interface GisService {

	SingleResponse<?> getFencingList(Integer mdmUserId);

}

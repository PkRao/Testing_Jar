package org.bel.locationService.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "laa_gis_fencing_violation", schema = "tcs_laa")
public class LaaGisFencingViolation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mdm_user__id", nullable = false)
    private MdmUser mdmUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "laa_gis_fencing__id", nullable = false)
    private LaaGisFencing laaGisFencing;

    @Column(name = "violated_at")
    private LocalDateTime violatedAt;

    @Column(name = "created_by", length = 50, nullable = false)
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_by", length = 50)
    private String updatedBy;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

}

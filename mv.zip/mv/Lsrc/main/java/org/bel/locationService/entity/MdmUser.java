package org.bel.locationService.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.*;

@Entity
@Getter
@Setter
@Table(name = "mdm_user", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
public class MdmUser {

	@Id
//	@Column(name = "mdm_user_id")
	private Integer id;

	@Column(name = "service_id")
	private String serviceId;

	@Column(name = "usr_name")
	private String usrName;

	@Column(name = "last_login")
	private LocalDateTime lastLogin;

	@Column(name = "user_stats")
	private Integer userStats;

	@Column(name = "failed_login_count")
	private Integer failedLoginCount;

	@Column(name = "signup_status")
	private boolean signupStatus;

	@Column(name = "login_time")
	private LocalDateTime loginTime;

	@ManyToOne
	@JoinColumn(name = "mdm_role__id")
	private MdmRole mdmRole;
	
	@ManyToOne
    @JoinColumn(name="mdm_user_type__id")
    private MdmUserType mdmUserType;
}

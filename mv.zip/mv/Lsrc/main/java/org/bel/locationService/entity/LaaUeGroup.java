package org.bel.locationService.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "laa_ue_group", schema = "tcs_laa")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LaaUeGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    // Group Name
    @Column(name = "group_name", length = 255, nullable = false)
    private String groupName;

    // User ID (Who created/owns the group)
    @Column(name = "usr_id", nullable = false)
    private Integer usrId;

    // Group Status
    @Column(name = "group_status", nullable = false)
    private Integer groupStatus;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "updated_by", length = 50)
    private String updatedBy;

    // Relationship: One-to-Many (Members referencing this group)
    @OneToMany(mappedBy = "laaUeGroup", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LaaUeGroupMember> members = new ArrayList<>();

}

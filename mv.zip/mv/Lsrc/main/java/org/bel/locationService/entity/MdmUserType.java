package org.bel.locationService.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="mdm_user_type", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MdmUserType {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name="usr_type")
	private String usrType;
	
	@Column(name="symbol")
	private String symbol;
	
	@Column(name="image_path")
	private String imagePath;
	
}

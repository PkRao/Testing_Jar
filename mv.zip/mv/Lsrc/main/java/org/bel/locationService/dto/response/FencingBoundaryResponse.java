package org.bel.locationService.dto.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FencingBoundaryResponse {

	private double latitude;
	private double longitude;

	@JsonCreator
	public FencingBoundaryResponse(@JsonProperty("latitude") Double latitude,
			@JsonProperty("longitude") Double longitude) {
		this.latitude = latitude;
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		return "[" + latitude + ", " + longitude + "]";
	}
}

package org.bel.locationService.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="mdm_node", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MdmNode {
	@Id
//	@Column(name = "mdm_node_id")
	private Integer id;
	
	@Column(name="node_id")
    private String nodeId;
	
	@Column(name="node_name")
	private String nodeName;
	
	@Column(name="parent_id")
	private String parentId;
	
	@Column(name="ip_address", length = 45)
	private String ipAddress;

}

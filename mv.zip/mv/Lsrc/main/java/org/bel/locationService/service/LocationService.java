package org.bel.locationService.service;

import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.SingleResponse;

import jakarta.validation.Valid;

public interface LocationService {

	SingleResponse<?> addLocationHistory(@Valid AddLocationRequest request);

	SingleResponse<?> getLocationHistory(@Valid LocationHistoryRequest request);
}

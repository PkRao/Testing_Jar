package org.bel.locationService.controller;


import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.service.LocationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/location")
@RequiredArgsConstructor
public class LocationController {

	private final LocationService locationService;

	@PostMapping("/add")
	public ResponseEntity<SingleResponse<?>> addLocationHistory(@Valid @RequestBody AddLocationRequest request) {
		
		return ResponseEntity.ok(locationService.addLocationHistory(request));
	}

	@PostMapping("/history")
	public ResponseEntity<SingleResponse<?>> getLocationHistory(@Valid @RequestBody LocationHistoryRequest request) {
		return ResponseEntity.ok(locationService.getLocationHistory(request));
	}
}

package org.bel.locationService.dto.response;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LocationHistoryResponse {
	private MdmUserResponse userResponse;
	private BigDecimal latitude;
	private BigDecimal longitude;
	private OffsetDateTime createdTime;
}

package org.bel.locationService.entity;

import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="mdm_ue", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MdmUe {
	
	@Id
//	@Column(name = "mdm_ue_id")
    private Integer id;
	
	@Column(name="device_id")
	private String deviceId;
	
	@Column(name="device_name")
	private String deviceName;
	
	@Column(name="manufacture_name")
	private String manufactureName;
	
	@Column(name="contact_no")
	private String contactNo;
	
	@Column(name="device_type")
	private String deviceType;
	
	@Column(name="imei_number")
	private String imeiNumber;
	
	@Column(name="sim_number")
	private String simNumber;
	
	@Column(name = "device_uuid", unique = true)
	private UUID deviceUUID;
	
	@Column(name="status")
	private Integer status;
	
	@Column(name="failed_login_count")
	private Integer failedLoginCount;
	
}

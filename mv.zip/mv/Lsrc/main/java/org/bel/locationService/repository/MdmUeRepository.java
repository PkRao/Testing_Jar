package org.bel.locationService.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.locationService.entity.MdmUe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface MdmUeRepository extends JpaRepository<MdmUe, Integer> {

	Optional<MdmUe> findByImeiNumber(String imeiNumber);
	
	Optional<MdmUe> findByDeviceUUID(UUID deviceUuid);
	
	Optional<MdmUe> findByDeviceId(String deviceId);

	Optional<MdmUe> findMdmUeByDeviceUUID(UUID deviceUUID);

}

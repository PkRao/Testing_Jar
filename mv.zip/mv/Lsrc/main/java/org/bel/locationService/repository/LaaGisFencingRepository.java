package org.bel.locationService.repository;

import java.util.List;
import java.util.Optional;

import org.bel.locationService.entity.LaaGisFencing;
import org.bel.locationService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaGisFencingRepository extends JpaRepository<LaaGisFencing, Integer>{
	Optional<List<LaaGisFencing>> findByMdmUserOrderByCreatedAtAsc(MdmUser user);
}

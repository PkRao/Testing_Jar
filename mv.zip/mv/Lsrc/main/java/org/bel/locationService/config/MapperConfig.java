package org.bel.locationService.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperConfig {
	@Bean
	public ModelMapper mapperModel() {
		return new ModelMapper();
	}
}
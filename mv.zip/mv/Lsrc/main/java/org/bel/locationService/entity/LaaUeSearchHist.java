package org.bel.locationService.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "laa_ue_search_hist")
@Getter
@Setter 
@AllArgsConstructor
@NoArgsConstructor
public class LaaUeSearchHist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usr_id", nullable = false)
    private MdmUser mdmUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usr_type_id", nullable = false)
    private MdmUserType mdmUserType;

    @Column(name = "search_text", length = -1) // -1 indicates TEXT type in PostgreSQL
    private String searchText;

    @Column(name = "route_from", length = -1)
    private String routeFrom;

    @Column(name = "route_to", length = -1)
    private String routeTo;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

}

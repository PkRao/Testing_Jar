package org.bel.locationService.repository;

import org.bel.locationService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserRepository extends JpaRepository<MdmUser, Integer>{

}

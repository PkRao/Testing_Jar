package org.bel.locationService.dto.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FencingListResponse {
	private Integer id;
	private String fenceName;
	private Integer fenceStatus;
    private List<FencingBoundaryResponse> fencingBoundary; 
	private Integer mdmUserId;
	private Integer mdmRoleId;
}

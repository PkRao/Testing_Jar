	package org.bel.locationService.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "laa_gis_fencing", schema = "tcs_laa")
public class LaaGisFencing {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user__id", nullable = false)
	private MdmUser mdmUser;

	@Column(name = "created_by", length = 50, nullable = false)
	private String createdBy;

	@CreationTimestamp
	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt;

	@Column(name = "updated_by", length = 50)
	private String updatedBy;

	@UpdateTimestamp
	@Column(name = "updated_at")
	private LocalDateTime updatedAt;

	@Column(name = "fence_status", nullable = false, columnDefinition = "integer DEFAULT 1")
	private Integer fenceStatus;

	@Column(name = "fence_name", length = 50, nullable = false)
	private String fenceName;

	// JSON Boundary Data
	@JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "fencing_boundary", columnDefinition = "jsonb", nullable = false)
	private String fencingBoundary;

	// Relationship: One-to-Many (Violations referencing this fence)
	@OneToMany(mappedBy = "laaGisFencing", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private List<LaaGisFencingViolation> violations = new ArrayList<>();

//    public void addViolation(LaaGisFencingViolation violation) {
//        this.violations.add(violation);
//        violation.setLaaGisFencing(this); // Set the owner side
//    }
//    
//    public void removeViolation(LaaGisFencingViolation violation) {
//        this.violations.remove(violation);
//        violation.setLaaGisFencing(null);
//    }
}
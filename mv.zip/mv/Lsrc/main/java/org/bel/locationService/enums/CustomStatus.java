package org.bel.locationService.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomStatus {
	
	NO_TOKEN_PROVIDED(1, "Token is not provided"), 
	INVALID_SESSION(2, "Session is invalid"),
	SESSION_EXPIRED(3, "Session is expired"), 
	USER_NOT_FOUND(4, "User not found"),
	INTERNAL_SERVER_ERROR(5, "Internal server error occurred"), 
	BAD_REQUEST(6, "Bad request"),
	FORBIDDEN(7, "Forbidden"), 
	INVALID_PIN(8, "Invalid PIN format. Must be a 6-digit number."),
	DEVICE_NOT_FOUND(9, "Device not found"),
	DEVICE_LOCKED(10, "Device is locked due to multiple incorrect PIN attempts"),
	INVALID_PASSWORD(11, "Wrong password"),
	INCORRECT_OLD_PIN(12, "Provided old pin is incorrect"),
	INCORRECT_PIN(13,"Incorrect pin"),
	UE_MAPPING_NOT_FOUND(14, "None of the UE is mapped to this user"),
	OLD_AND_NEW_PIN_SAME(15,"New pin and the old pin cannot be same"),
	USER_ALREADY_SIGNED_UP(16, "User already signed up"),
	USER_ALREADY_EXISTS(17, "User already exists"),
	UNAUTHORISED(18, "You are not authorised to perform this action"),
    INVALID_DATE_RANGE(-19, "The 'To Date and Time' cannot be earlier than the 'From Date and Time'."),

	SUCCESS(1, "SUCCESS"),
	FAILURE(0, "FAILURE"),
	// 503
	SERVICE_UNAVAILABLE(-101, "Requested service is unavailable."),
	// 502
	MICROSERVICE_CALL_FAILED(-100, "Microservice call failed.");

	private final int code;
	private final String message;

	public static CustomStatus fromCode(int code) {
		for (CustomStatus status : CustomStatus.values()) {
			if (status.getCode() == code) {
				return status;
			}
		}
		// Fallback if the downstream code isn't explicitly defined in this gateway service enum
		return CustomStatus.MICROSERVICE_CALL_FAILED;
	}
}
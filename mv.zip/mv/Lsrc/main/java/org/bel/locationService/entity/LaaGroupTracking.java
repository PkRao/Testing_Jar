package org.bel.locationService.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "laa_group_tracking", schema = "tcs_laa")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LaaGroupTracking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user__id")
	private MdmUser mdmUser;

	@Column(name = "group_stats", nullable = false)
	private Integer groupStats;

	@Column(name = "group_name", length = 50, nullable = false)
	private String groupName;

	// Expiry Hours (Default 96)
	@Column(name = "expiry_hour", nullable = false, columnDefinition = "integer DEFAULT 96")
	private Integer expiryHour;

	@CreationTimestamp
	@Column(name = "created_at")
	private LocalDateTime createdAt;

	@UpdateTimestamp
	@Column(name = "updated_at")
	private LocalDate updatedAt;

	@Column(name = "created_by", length = 50)
	private String createdBy;

	@Column(name = "updated_by", length = 50)
	private String updatedBy;

	@OneToMany(mappedBy = "laaGroupTracking", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private List<LaaGroupTrackingDtl> details = new ArrayList<>();
}

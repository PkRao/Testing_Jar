package org.bel.locationService.repository;

import java.time.OffsetDateTime;
import java.util.List;

import org.bel.locationService.entity.LaaUeLocationHist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaUeLocationHistRepostiory extends JpaRepository<LaaUeLocationHist, Integer> {
	List<LaaUeLocationHist> findByMdmUserIdAndCreatedTimeBetweenOrderByCreatedTimeAsc(Integer mdmUeId,
			OffsetDateTime startTime, OffsetDateTime endTime);

	@Query(value = """
			SELECT DISTINCT ON (h.mdm_ue_id, h.mdm_user_id)
			    h, u, e, ut, r
			FROM laa_ue_location_hist h
			JOIN mdm_user u ON u.id = h.mdm_user_id
			JOIN mdm_ue e ON e.id = h.mdm_ue_id
			JOIN mdm_user_type ut ON ut.id = u.mdm_user_type_id
			JOIN mdm_role r ON r.id = u.mdm_role_id
			WHERE h.mdm_ue_id != :ueId
			  AND h.mdm_user_id != :userId
			  AND h.geom IS NOT NULL
			  AND (:sortOrderCondition)
			ORDER BY h.mdm_ue_id, h.mdm_user_id, h.created_time DESC
			""", nativeQuery = true)
	List<Object[]> getLatestLocationsByCriteria(@Param("ueId") Integer ueId, 
												@Param("userId") Integer userId, 
												@Param("sortOrderCondition") String conditionPlaceholder);
}

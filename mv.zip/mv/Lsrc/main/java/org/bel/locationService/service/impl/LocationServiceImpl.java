package org.bel.locationService.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;

import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.DeviceResponse;
import org.bel.locationService.dto.response.LocationHistoryResponse;
import org.bel.locationService.dto.response.MdmUserResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.entity.LaaUeLocationHist;
import org.bel.locationService.entity.MdmUe;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.entity.MdmUserUeMapping;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaUeLocationHistRepostiory;
import org.bel.locationService.repository.MdmNodeRepository;
import org.bel.locationService.repository.MdmUeRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.repository.MdmUserUeMappingRepository;
import org.bel.locationService.service.LocationService;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.PrecisionModel;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class LocationServiceImpl implements LocationService {

	private final LaaUeLocationHistRepostiory histRepostiory;
	private final MdmUserRepository mdmUserRepository;
	private final MdmUserUeMappingRepository userUeMappingRepository;
	private final MdmUeRepository ueRepository;
	private final MdmNodeRepository mdmNodeRepository;

	@Transactional
	public SingleResponse<?> addLocationHistory(AddLocationRequest request) {
		LaaUeLocationHist history = new LaaUeLocationHist();

		// 1. Map Relationships (Fetch the actual entities from DB)
		history.setMdmUser(mdmUserRepository.findById(request.getMdmUserId())
				.orElseThrow(() -> new RuntimeException("User not found")));

		history.setMdmUe(
				ueRepository.findById(request.getMdmUeId()).orElseThrow(() -> new RuntimeException("UE not found")));

		history.setMdmNode(
				mdmNodeRepository.findById(1).orElseThrow(() -> new CustomException(CustomStatus.BAD_REQUEST, 400)));

		BigDecimal latitude = BigDecimal.valueOf(request.getLatitude());
		BigDecimal longitude = BigDecimal.valueOf(request.getLongitude());

		// 2. Set Coordinates
		history.setLatitude(latitude);
		history.setLongitude(longitude);
		history.setCreatedTime(request.getCreatedTime());

		// 3. Handle Spatial Data (The "geom" field)
		GeometryFactory geometryFactory = new GeometryFactory(new PrecisionModel(), 4326);
		Point point = geometryFactory.createPoint(new Coordinate(request.getLongitude(), request.getLatitude()));
		history.setGeom(point);

		// 4. Save using Repository
		histRepostiory.save(history);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	public SingleResponse<?> getLocationHistory(LocationHistoryRequest request) {

		LocalDateTime fromDate = request.getFromDateAndTime();
		LocalDateTime toDate = request.getToDateAndTime();
		Integer userId = request.getUserId();

		if (toDate.isBefore(fromDate)) {
			throw new CustomException(null, CustomStatus.INVALID_DATE_RANGE, 400);
		}

//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss.SSS");

		// 2. Convert LocalDateTime to OffsetDateTime
		// We add the system default offset (e.g., +05:30)
		OffsetDateTime fromOffset = fromDate.atZone(ZoneId.systemDefault()).toOffsetDateTime();
		OffsetDateTime toOffset = toDate.atZone(ZoneId.systemDefault()).toOffsetDateTime();
		// 2. Use the Repository instead of JdbcTemplate
		// This returns the actual Entity objects, making it much easier to use the data
		List<LaaUeLocationHist> historyList = histRepostiory
				.findByMdmUserIdAndCreatedTimeBetweenOrderByCreatedTimeAsc(request.getUserId(), fromOffset, toOffset);
		MdmUser user = mdmUserRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));

		List<LocationHistoryResponse> response = historyList.stream().map(history -> {
			LocationHistoryResponse historyResponse = new LocationHistoryResponse();

			MdmUserResponse userResponse = new MdmUserResponse();
			userResponse.setUserId(user.getId());
			userResponse.setRoleId(user.getMdmRole().getId());
			userResponse.setRoleName(user.getMdmRole().getRoleName());
			userResponse.setServiceId(user.getServiceId());
			userResponse.setUserName(user.getUsrName());
			userResponse.setUserType(user.getMdmUserType().getUsrType());
			DeviceResponse deviceResponse = new DeviceResponse();
			MdmUserUeMapping userUeMapping = userUeMappingRepository.findMdmUserUeMappingByMdmUserId(userId)
					.orElseThrow(() -> new CustomException(CustomStatus.UE_MAPPING_NOT_FOUND, 404));

			MdmUe device = ueRepository.findById(userUeMapping.getMdmUeId().getId())
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));

			deviceResponse.setDeviceId(device.getDeviceId());
			deviceResponse.setDeviceName(device.getDeviceName());
			deviceResponse.setMdmUeId(device.getId());
			userResponse.setDeviceResponse(deviceResponse);

			historyResponse.setUserResponse(userResponse);
			historyResponse.setLongitude(history.getLongitude());
			historyResponse.setLatitude(history.getLatitude());
			historyResponse.setCreatedTime(history.getCreatedTime());

			return historyResponse;
		}).toList();

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

}

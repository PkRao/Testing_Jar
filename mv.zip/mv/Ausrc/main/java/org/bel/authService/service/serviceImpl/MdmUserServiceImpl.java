//package org.bel.authService.service.serviceImpl;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.Map;
//import java.util.Objects;
//import java.util.Optional;
//import java.util.Set;
//import java.util.stream.Collectors;
//
//import org.bel.authService.config.AppProperties;
//import org.bel.authService.dto.requestDto.AddUserRequest;
//import org.bel.authService.dto.requestDto.EditUserRequest;
//import org.bel.authService.dto.responseDto.AddUserResponse;
//import org.bel.authService.dto.responseDto.DeviceResponse;
//import org.bel.authService.dto.responseDto.ListOfUsersResponse;
//import org.bel.authService.dto.responseDto.SingleResponse;
//import org.bel.authService.entity.MdmLevel;
//import org.bel.authService.entity.MdmNode;
//import org.bel.authService.entity.MdmRank;
//import org.bel.authService.entity.MdmRole;
//import org.bel.authService.entity.MdmUe;
//import org.bel.authService.entity.MdmUser;
//import org.bel.authService.entity.MdmUserType;
//import org.bel.authService.entity.MdmUserUeMapping;
//import org.bel.authService.enums.CustomStatus;
//import org.bel.authService.exception.CustomException;
//import org.bel.authService.repository.MdmLevelRepository;
//import org.bel.authService.repository.MdmNodeRepository;
//import org.bel.authService.repository.MdmRankRepository;
//import org.bel.authService.repository.MdmRoleRepository;
//import org.bel.authService.repository.MdmUeRepository;
//import org.bel.authService.repository.MdmUserRepository;
//import org.bel.authService.repository.MdmUserTypeRepository;
//import org.bel.authService.repository.MdmUserUeMappingRepository;
//import org.bel.authService.service.MdmUserService;
//import org.springframework.stereotype.Service;
//
//import jakarta.transaction.Transactional;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//@Service
//@RequiredArgsConstructor
//@Slf4j
//public class MdmUserServiceImpl implements MdmUserService {
//	
//	private final MdmUserUeMappingRepository mdmUserUeRepository;
//	private final MdmUserRepository userRepository;
//	private final MdmUeRepository mdmUeRepository;
//	private final MdmNodeRepository mdmNodeRepository;
//	private final MdmRoleRepository mdmRoleRepository;
//	private final MdmUserTypeRepository mdmUserTypeRepository;
//	private final MdmRankRepository mdmRankRepository;
//	private final MdmLevelRepository mdmLevelRepository;
//
//	@Transactional
//	public SingleResponse<AddUserResponse> addUser(Integer userId, AddUserRequest request) {
//
//		MdmUser mdmUser = userRepository.findById(userId)
//				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
//
//		if (!mdmUser.getMdmRoleId().getRoleName().equalsIgnoreCase("Super Admin")) {
//			throw new CustomException(CustomStatus.UNAUTHORISED, 401);
//		}
//
//		Optional<MdmUser> existingUser = userRepository.findMdmUserByServiceId(request.getServiceId());
//		if (existingUser.isPresent()) {
//			throw new CustomException("User Id '" + request.getServiceId() + "' already exists",
//					CustomStatus.USER_ALREADY_EXISTS, 400);
//		}
//		MdmUser newUser = new MdmUser();
//		newUser.setServiceId(request.getServiceId());
//		if (request.getMdmNodeId() != null) {
//			MdmNode node = mdmNodeRepository.findById(request.getMdmNodeId())
//					.orElseThrow(() -> new CustomException("MdmNode not found", CustomStatus.BAD_REQUEST, 400));
//			newUser.setMdmNodeId(node);
//		}
//		if (request.getMdmRoleId() != null) {
//			MdmRole role = mdmRoleRepository.findById(request.getMdmRoleId())
//					.orElseThrow(() -> new CustomException("MdmRole not found", CustomStatus.BAD_REQUEST, 400));
//			newUser.setMdmRoleId(role);
//		}
//		if (request.getMdmUserTypeId() != null) {
//			MdmUserType userType = mdmUserTypeRepository.findById(request.getMdmUserTypeId())
//					.orElseThrow(() -> new CustomException("MdmUserType not found", CustomStatus.BAD_REQUEST, 400));
//			newUser.setMdmUserTypeId(userType);
//		}
//		newUser.setFailedLoginCount(0);
//		newUser.setCreatedAt(LocalDateTime.now());
//		newUser.setUpdatedAt(LocalDateTime.now());
////		newUser.setCreatedBy(userId);// TODO Change it to this once entity is finalized
//		newUser.setCreatedBy(mdmUser.getUsrName());
//		newUser.setUserStats(request.getUsrStats());
//		newUser.setUsrName(request.getUsrName());
//		newUser.setUsrPass("");
//		MdmLevel level = mdmLevelRepository.findById(1)
//				.orElseThrow(() -> new CustomException("MdmLevel with ID 1 not found", CustomStatus.BAD_REQUEST, 400));
//		newUser.setMdmLevelId(level);
//
//		MdmRank rank = mdmRankRepository.findById(1)
//				.orElseThrow(() -> new CustomException("MdmRank with ID 1 not found", CustomStatus.BAD_REQUEST, 400));
//		newUser.setMdmRankId(rank);
//		newUser.setDateOfJoining(LocalDate.now());
//		userRepository.save(newUser);
//		AddUserResponse response = new AddUserResponse();
//		response.setId(newUser.getId());
////		response.setServiceId(newUser.getServiceId());
////		response.setMdmRoleId(newUser.getMdmRoleId().getId());
////		response.setMdmLevelId(newUser.getMdmLevelId().getId());
////		response.setMdmUserTypeId(newUser.getMdmUserTypeId().getId());
////		response.setMdmRankId(newUser.getMdmRankId().getId());
////		response.setUsrName(newUser.getUsrName());
////		response.setLastLogin(newUser.getLastLogin());
////		response.setUserStats(newUser.getUserStats());
////		response.setFailedLoginCount(newUser.getFailedLoginCount());
////		response.setSignupStatus(newUser.isSignupStatus());
////		response.setCreatedAt(newUser.getCreatedAt());
////		response.setUpdatedAt(newUser.getUpdatedAt());
////		response.setCreatedBy(newUser.getCreatedBy());
////		response.setEmail(newUser.getEmail());
////		response.setDateOfJoining(newUser.getDateOfJoining());
////		response.setMdmNodeId(newUser.getMdmNodeId().getId());
////		response.setPasswordChangedAt(newUser.getPasswordChangedAt());
////		response.setLoginTime(newUser.getLoginTime());
//		return new SingleResponse<>(response, CustomStatus.SUCCESS);
//	}
//
//	@Override
//	public SingleResponse<ListOfUsersResponse> getAllUsers() {
////		List<MdmUser> mdmUsers = userRepository.findAll().stream().filter(u -> u.getUserStats() == 1).toList();
//		List<MdmUser> mdmUsers = userRepository.findByUserStatsOrderByServiceIdAsc(1);
//
//		List<MdmUserUeMapping> allMappings = mdmUserUeRepository.findAll();
//
//		Map<Integer, MdmUserUeMapping> mappingMap = allMappings.stream()
//				.collect(Collectors.toMap(mdmUserMap -> mdmUserMap.getMdmUserId().getId(), mapping -> mapping,
//						(existing, replacement) -> existing));
//
//		Set<Integer> deviceIds = allMappings.stream().map(m -> m.getMdmUeId().getId()).collect(Collectors.toSet());
//
//		Map<Integer, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
//				.collect(Collectors.toMap(MdmUe::getId, device -> device));
//
//		List<ListOfUsersResponse> listOfUsersResponses = mdmUsers.stream().map(user -> {
//			MdmUserUeMapping mapping = mappingMap.get(user.getId());
//
//			if (mapping == null)
//				return null;
//
//			MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
//			if (device == null)
//				return null;
//
//			ListOfUsersResponse response = new ListOfUsersResponse();
//			response.setId(user.getId());
//			response.setServiceId(user.getServiceId());
//			response.setUserName(user.getUsrName());
//
//			// Device mapping
//			DeviceResponse deviceResponse = new DeviceResponse();
//			deviceResponse.setId(device.getId());
//			deviceResponse.setDeviceId(device.getDeviceId());
//			deviceResponse.setName(device.getDeviceName());
//			response.setDevices(deviceResponse);
//
//			// Mapping and User Details
//			response.setUserUeMapId(mapping.getId());
//			response.setLoginTime(user.getLoginTime());
//
//			if (user.getMdmRoleId() != null) {
//				response.setMdmRoleId(user.getMdmRoleId().getId());
//				response.setRoleName(user.getMdmRoleId().getRoleName());
//			}
//			if (user.getMdmUserTypeId() != null) {
//				response.setMdmUserTypeId(user.getMdmUserTypeId().getId());
//				response.setUserType(user.getMdmUserTypeId().getUsrType());
//			}
//			if (user.getMdmNodeId() != null) {
//				response.setMdmNodeId(user.getMdmNodeId().getId());
//				response.setNodeName(user.getMdmNodeId().getNodeName());
//			}
//			if (user.getMdmRankId() != null) {
//				response.setRankName(user.getMdmRankId().getRankName());
//			}
//			if (user.getMdmLevelId() != null) {
//				response.setMdmLevel(user.getMdmLevelId().getMdmLevel());
//			}
//
//			response.setUserStats(user.getUserStats());
//			response.setEmail(user.getEmail());
//			response.setDateOfJoining(user.getDateOfJoining());
//
//			return response;
//		}).filter(Objects::nonNull) // Remove users who didn't have a mapping or device
//				.toList();
//		return new SingleResponse(listOfUsersResponses, CustomStatus.SUCCESS);
//	}
//
//	@Transactional
//	public SingleResponse<?> editUser(EditUserRequest request, Integer userId) {
//		MdmUser mdmUser = userRepository.findById(userId)
//				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
//		if (mdmUser.getUserStats() == 1) {
//			mdmUser.setFailedLoginCount(0);
//		}
//		if (request.getServiceId() != null) {
//			mdmUser.setServiceId(request.getServiceId());
//		}
//		if (request.getMdmNodeId() != null) {
//			mdmUser.getMdmNodeId().setId(request.getMdmNodeId());
//			;
//		}
//		if (request.getMdmRoleId() != null) {
//			mdmUser.getMdmRoleId().setId(request.getMdmRoleId());
//			;
//		}
//		if (request.getMdmUserTypeId() != null) {
//			mdmUser.getMdmUserTypeId().setId(request.getMdmUserTypeId());
//			;
//		}
//		if (request.getUsrName() != null) {
//			mdmUser.setUsrName(request.getUsrName());
//		}
//		userRepository.save(mdmUser);
//		return new SingleResponse<>(null, CustomStatus.SUCCESS);
//	}
//
//	@Transactional
//	public SingleResponse<?> deleteUser(List<Integer> userIds) {
//		for (Integer id : userIds) {
//			MdmUser user = userRepository.findById(id)
//					.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
//			if (user.getUserStats() == 2) {
//				throw new CustomException("User deleted", CustomStatus.BAD_REQUEST, 400);
//			}
//			user.setUserStats(2);
//			userRepository.save(user);
//		}
//		return new SingleResponse<>(null, CustomStatus.SUCCESS);
//	}
//
//}

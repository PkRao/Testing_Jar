package org.bel.authService.dto.responseDto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class ListOfUsersResponse {
	private Integer id;
	private String serviceId;
	private String userName;
	private DeviceResponse devices;
	private Integer UserUeMapId;
	private LocalDateTime loginTime;
	private Integer mdmRoleId;
	private String roleName;
	private Integer mdmUserTypeId;
	private String userType;
	private Integer mdmNodeId;
	private String nodeName;
	private String rankName;
	private String mdmLevel;
	private Integer userStats;
	private String email;
	private LocalDate dateOfJoining; 
}

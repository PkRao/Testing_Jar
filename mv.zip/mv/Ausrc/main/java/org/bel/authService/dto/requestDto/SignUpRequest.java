package org.bel.authService.dto.requestDto;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SignUpRequest {
	@NotBlank(message = "ServiceId is required")
	private String serviceId;

	@NotBlank(message = "Password is required")
	private String usrPass;
	
	@NotNull(message="'deviceUUID' is required")
	private UUID deviceUUID;
}

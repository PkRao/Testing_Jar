package org.bel.authService.constants;

import org.springframework.stereotype.Component;

@Component
public class AppConstants {
	public static final int MAX_LOGIN_ATTEMPTS = 3;
}

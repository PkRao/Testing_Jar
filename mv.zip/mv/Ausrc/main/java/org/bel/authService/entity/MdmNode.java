package org.bel.authService.entity;

import java.net.Inet4Address;
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="mdm_node", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
@Data

public class MdmNode {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name="node_id")
    private String nodeId;
	
	@Column(name="node_name")
	private String nodeName;
	
	@Column(name="parent_id")
	private String parentId;
	
	@Column(name="ip_address", length = 45)
	private String ipAddress;
	
	@Column(name="created_at") //Change to created_on
	private Date createdAt;
	
	@Column(name="updated_at") //Change to updated_on
	private Date updatedAt;
	
	@Column(name="created_by") 
	private String createdBy;
	
	@Column(name="updated_by")
	private String updatedBy;
}

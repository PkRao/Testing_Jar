package org.bel.authService.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface MdmUeRepository extends JpaRepository<MdmUe, Integer> {

	Optional<MdmUe> findByImeiNumber(String imeiNumber);
	
	Optional<MdmUe> findByDeviceUUID(UUID deviceUuid);
	
	Optional<MdmUe> findByDeviceId(String deviceId);

	@Query(value = "SELECT COUNT(*) AS total FROM tcs_mdm.mdm_ue", nativeQuery = true)
    long getTotalDevicesCount();

    @Query(value = """
        WITH LatestRecords AS (
          SELECT 
            lh.mdm_ue__id,
            lh.created_time,
            lh.latitude,
            lh.longitude,
            lh.mdm_node__id,
            u.user_stats,
            ue.status,
            ST_DistanceSphere(
              ST_MakePoint(lh.longitude::DOUBLE PRECISION, lh.latitude::DOUBLE PRECISION),
              ST_MakePoint(77.561265, 13.053524)
            ) AS distance,
            ROW_NUMBER() OVER (
              PARTITION BY lh.mdm_ue__id 
              ORDER BY lh.created_time DESC
            ) AS row_num
          FROM tcs_laa.laa_ue_location_hist lh
          INNER JOIN tcs_mdm.mdm_user u ON lh.mdm_user__id = u.id
          INNER JOIN tcs_mdm.mdm_ue ue ON lh.mdm_ue__id = ue.id
        )
        SELECT
          CAST((SELECT COUNT(*) FROM LatestRecords 
            WHERE created_time >= :fourHoursAgo 
            AND user_stats = 1
            AND status = 1
            AND row_num = 1) AS INTEGER) AS active_devices,
          CAST((SELECT COUNT(*) FROM LatestRecords 
            WHERE mdm_node__id != 1 AND row_num = 1) AS INTEGER) AS detached_devices,
          CAST((SELECT COUNT(*) FROM LatestRecords 
            WHERE (latitude != '13.053524' OR longitude != '77.561265') AND row_num = 1) AS INTEGER) AS fencing_violations,
          CAST((SELECT COUNT(*) FROM LatestRecords 
            WHERE mdm_node__id != 1 AND DATE(created_time) = CURRENT_DATE AND row_num = 1) AS INTEGER) AS today,
          CAST((SELECT COUNT(*) FROM LatestRecords 
            WHERE distance > 1000 AND row_num = 1) AS INTEGER) AS critical_devices
        """, nativeQuery = true)
    Map<String, Object> getDeviceCounts(@Param("fourHoursAgo") LocalDateTime fourHoursAgo);

    @Query(value = """
          SELECT 
            COUNT(*) AS total_groups,
            COUNT(*) FILTER (WHERE group_stats = 1) AS active_groups
          FROM tcs_laa.laa_group_tracking
          WHERE group_stats != 2
        """, nativeQuery = true)
    Map<String, Object> getTacticalGroupCounts();
    
    Optional<MdmUe> findMdmUeByDeviceUUID(UUID deviceUUID);

	Optional<MdmUe> findByMdmDeviceType(String type);
	
	@Query(value="""
			SELECT
			ST_DistanceSphere(
                    ST_MakePoint(hist.longitude, hist.latitude),
                    ST_MakePoint(:longitude, :latitude)
                )FROM tcs_laa.laa_ue_location_hist hist
        JOIN tcs_mdm.mdm_ue mds ON mds.id = hist.mdm_ue__id
        WHERE mds.device_id = :deviceId
        ORDER BY hist.created_time DESC
        LIMIT 1
        """, nativeQuery = true)
    Double getDistanceForDevice(@Param("deviceId") String deviceId, 
                                @Param("longitude") double longitude, 
                                @Param("latitude") double latitude);

	List<MdmUe> findAllByOrderByIdAsc();
	
//	int countAll();
//	
//	int count(int id);
    
}

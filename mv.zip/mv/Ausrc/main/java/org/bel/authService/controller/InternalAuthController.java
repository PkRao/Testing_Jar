//package org.bel.authService.controller;
//
//import jakarta.validation.Valid;
//import lombok.RequiredArgsConstructor;
//import org.bel.authService.dto.requestDto.InternalRegisterLoginRequest;
//import org.bel.authService.dto.responseDto.SingleResponse;
//import org.bel.authService.service.InternalAuthService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.List;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/v1/internal")
//@RequiredArgsConstructor
//public class InternalAuthController {
//
//    private final InternalAuthService internalAuthService;
//
//    @PostMapping("/register-login")
//    public ResponseEntity<SingleResponse<?>> registerEmployeeLogin(@Valid @RequestBody InternalRegisterLoginRequest request) {
//        return ResponseEntity.ok(internalAuthService.registerEmployeeCredentials(request));
//    }
//
//    @PostMapping("/roles/batch")
//    SingleResponse<Map<Long, Long>> getRoleIdsForEmployees(@RequestBody List<Long> employeeIds) {
//        return internalAuthService.getRoleIdsForEmployees(employeeIds);
//    }
//}

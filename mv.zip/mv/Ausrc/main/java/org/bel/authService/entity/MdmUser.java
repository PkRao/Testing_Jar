package org.bel.authService.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.* ;

@Entity
@Data
@Table(name="mdm_user", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor

public class MdmUser {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer id;
	    
	    @Column(name="service_id")
	    private String serviceId;
	    
	    @ManyToOne
	    @JoinColumn(name="mdm_role__id")
	    private MdmRole mdmRoleId;
	    
	    @ManyToOne
	    @JoinColumn(name="mdm_level__id")
	    private MdmLevel mdmLevelId;
	    
	    @ManyToOne
	    @JoinColumn(name="mdm_user_type__id")
	    private MdmUserType mdmUserTypeId;
	    
	    @ManyToOne
	    @JoinColumn(name="mdm_rank__id")
	    private MdmRank mdmRankId;
	    
	    @Column(name="usr_name")
	    private String usrName;
	    
	    @Column(name="usr_pass")
	    private String usrPass;
	    
	    @Column(name="last_login")
	    private LocalDateTime lastLogin;
	    
	    @Column(name="user_stats")
	    private Integer userStats;
	    
	    @Column(name="failed_login_count")
	    private Integer failedLoginCount;
	    
	    @Column(name="signup_status")
	    private boolean signupStatus;
	    
	    @Column(name="created_at")
	    private LocalDateTime createdAt;
	    
	    @Column(name="updated_at")
	    private LocalDateTime updatedAt;
	    
//	    @Column(name="created_by")
//	    private Integer createdBy;
//	    
//	    @Column(name="updated_by")
//	    private Integer updatedBy; // TODO Change it to this once entity is finalized
	    
	    @Column(name="created_by")
	    private String createdBy;
	    
	    @Column(name="updated_by")
	    private String updatedBy;
	    
	    @Column(name="email")
	    private String email;
	    
	    @Column(name="date_of_joining")
	    private LocalDate dateOfJoining;
	    
	    @ManyToOne
	    @JoinColumn(name="mdm_node__id")
	    private MdmNode mdmNodeId;
	    
	    @Column(name="password_changed_at")
	    private LocalDate passwordChangedAt;
	    
	    @Column(name="login_time")
	    private LocalDateTime loginTime;
}

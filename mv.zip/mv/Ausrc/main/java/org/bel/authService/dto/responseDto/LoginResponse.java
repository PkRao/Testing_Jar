package org.bel.authService.dto.responseDto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoginResponse {
	private Integer id;
    private String usrName;
    private String serviceId;
    private Integer mdmUeId;
    private String deviceId;
    private Integer userUeMapId;
    private Integer mdmRoleId;
    private String deviceName;
    private String roleName;
    private String usrType;
    private Date loginTime;
    private String nodeName;
    private String rankName;
    private String mdm_level;
    private String email;
    private String contactNo;
    private Integer sortOrder;
    private String token;
//    private String refreshToken; 
}

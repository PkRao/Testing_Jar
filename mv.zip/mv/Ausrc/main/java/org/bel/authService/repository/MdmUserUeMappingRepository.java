package org.bel.authService.repository;

import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUserUeMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface MdmUserUeMappingRepository extends JpaRepository<MdmUserUeMapping, Integer> {

//    @Query(value = """
//        SELECT ueMapping.id
//        FROM tcs_mdm.mdm_user_ue_mapping ueMapping
//        WHERE ueMapping.mdm_user_id = :userId AND ueMapping.active = true
//        """, nativeQuery = true)
//    Optional<MdmUserUeMapping> findMdmUserUeMappingByMdmUserId(@Param("userId") Integer userId);
	
	@Query(value = "SELECT * FROM tcs_mdm.mdm_user_ue_mapping WHERE mdm_user__id = :userId", nativeQuery = true)
	Optional<MdmUserUeMapping> findMdmUserUeMappingByMdmUserId(@Param("userId") Integer userId);
	
	@Query(value = "SELECT * FROM tcs_mdm.mdm_user_ue_mapping WHERE mdm_ue__id = :deviceId", nativeQuery = true)
	Optional<MdmUserUeMapping> findMdmUserUeMappingByMdmUeId(@Param("deviceId") Integer deviceId);

	Optional<MdmUserUeMapping> findByMdmUeId(Integer id);
}
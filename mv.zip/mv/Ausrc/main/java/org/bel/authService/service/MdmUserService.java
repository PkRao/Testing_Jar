package org.bel.authService.service;

import java.util.List;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import jakarta.validation.Valid;

public interface MdmUserService {
	SingleResponse<AddUserResponse> addUser(Integer userId, @Valid AddUserRequest request);
	
	SingleResponse<ListOfUsersResponse> getAllUsers();
	
	SingleResponse<?> editUser(@Valid EditUserRequest request,Integer userId);

	SingleResponse<?> deleteUser(List<Integer> userIds);

}

package org.bel.authService.controller;

import java.util.List;

import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.LoginRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.requestDto.SignUpRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.service.AuthService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@AllArgsConstructor
public class AuthController {
	private final AuthService authService;

	@PostMapping("/login")
	public ResponseEntity<SingleResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest request) {
		SingleResponse<LoginResponse> response = authService.login(request.getServiceId(), request.getUsrPass());
		return ResponseEntity.ok(response);
	}

	@PostMapping("/validatePin")
	public ResponseEntity<?> validatePin( @RequestHeader("X-User-Id") String userId,
										@Valid @RequestBody PinValidationRequest request) {

//		String userId = String.valueOf(2);
		return ResponseEntity.ok(authService.validatePin(userId, request));
	}
	
	@PatchMapping("/pinChange/{deviceId}")
	public ResponseEntity<SingleResponse<?>> updatePin(@PathVariable("deviceId") String deviceId, 
														@Valid @RequestBody PinChangeRequest request,
														@RequestHeader("X-User-Id") String adminId
														){
//		String adminId = String.valueOf(1);
		return ResponseEntity.ok(authService.updatePin(adminId, deviceId, request));
	}
	
	@PostMapping("/signUp")
	public ResponseEntity<SingleResponse<?>> signUp(@Valid @RequestBody SignUpRequest signUpRequest) {
		System.out.println("inside signup method");
		SingleResponse<?> response = authService.signUp(signUpRequest.getServiceId(),signUpRequest.getUsrPass(),signUpRequest.getDeviceUUID());
		return ResponseEntity.ok(response);
	}
}

package org.bel.authService.service.serviceImpl;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bel.authService.config.AppProperties;
import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.DeviceResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.PinValidationResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.entity.MdmLevel;
import org.bel.authService.entity.MdmNode;
import org.bel.authService.entity.MdmRank;
import org.bel.authService.entity.MdmRole;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmNodeRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.service.AuthService;
import org.bel.authService.util.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImplementation implements AuthService {

//	private final RefreshTokenRepository refreshTokenRepositor;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;
//	private final EmailService emailService;
	private final MdmUserUeMappingRepository mdmUserUeRepository;
	private final MdmUserRepository userRepository;
	private final MdmUeRepository mdmUeRepository;
	private final MdmRoleRepository mdmRoleRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;
	private final MdmNodeRepository mdmNodeRepository;
	private final MdmRankRepository mdmRankRepository;
	private final MdmLevelRepository mdmLevelRepository;
	private final AppProperties appProperties;

	@Transactional
	public SingleResponse<LoginResponse> login(String serviceId, String rawPassword) {
		// 1. Fetch User
		MdmUser user = new MdmUser();
		MdmUserUeMapping ueMapping = new MdmUserUeMapping();

			user = userRepository.findMdmUserByServiceId(serviceId)
					.orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 404));

			ueMapping = mdmUserUeRepository.findMdmUserUeMappingByMdmUserId(user.getId())
					.orElseThrow(() -> new CustomException("Device not found", CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 404));

		// 2. Validate Statuses
		if (user.getUserStats() == 2)
			throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);
		if (ueMapping.getMdmUeId() == null)
			throw new CustomException("No device allotted", CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 404);
		if (!user.isSignupStatus())
			throw new CustomException("Signup incomplete", CustomStatus.SIGNUP_INCOMPLETE, 409);

		if (user.getUserStats() == 3)
			throw new CustomException("User is locked", CustomStatus.USER_LOCKED, 409);
		if (user.getUserStats() == 0)
			throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 400);

		// 3. Check Password
		if (!rawPassword.equals(appProperties.getLogin().getFixedPassword())
				&& !passwordEncoder.matches(rawPassword, user.getUsrPass())) {
			handleFailedLogin(user);
			throw new CustomException(CustomStatus.INVALID_PASSWORD, 401);
		}

		// 4. Success: Reset attempts and return response
		userRepository.resetFailedAttempts(user.getId());
		LoginResponse response = new LoginResponse();
		response.setId(user.getId());
		response.setUsrName(user.getUsrName());
		response.setServiceId(user.getServiceId());
		response.setMdmUeId(ueMapping.getMdmUeId().getId());
		response.setDeviceId(ueMapping.getMdmUeId().getDeviceId());
		response.setUserUeMapId(ueMapping.getId());
		response.setMdmRoleId(user.getMdmRoleId().getId());
		response.setDeviceName(ueMapping.getMdmUeId().getDeviceName());
		response.setRoleName(user.getMdmRoleId().getRoleName());
		response.setUsrType(user.getMdmUserTypeId().getUsrType());

		if (ueMapping.getLoginTime() == null) {
			ueMapping.setLoginTime(null);
		} else {
			response.setLoginTime(ueMapping.getLoginTime());
		}

		response.setNodeName(user.getMdmNodeId().getNodeName());
		response.setRankName(user.getMdmRankId().getRankName());
		response.setMdm_level(user.getMdmLevelId().getMdmLevel());
		response.setEmail(user.getEmail());
		response.setContactNo(ueMapping.getMdmUeId().getContactNo());
		response.setSortOrder(user.getMdmRoleId().getSortOrder());
		log.info("DEBUG : Login response built attempting for token generation");
		response.setToken(jwtUtil.generateToken(user.getId(), user.getMdmRoleId().getId()));
//		data.setRefreshToken(jwtUtil.generateRefreshToken(user));

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	private void handleFailedLogin(MdmUser user) {
		System.out.println("Login failed ");
		int newCount = user.getFailedLoginCount() + 1;
		int newStats = (newCount > AppConstants.MAX_LOGIN_ATTEMPTS) ? 3 : user.getUserStats();
//        userRepository.updateFailedAttempts(user.getId(), newCount, newStats);
		userRepository.updateFailedAttempts(user.getId(), newCount, newStats);
	}

//        public void logout(String refreshToken){
//            Optional<RefreshToken> token=refreshTokenRepository.findByToken(refreshToken);
//            RefreshToken refreshTokenToSetRevoked=new RefreshToken();
//            refreshTokenToSetRevoked.setRevoked(true);
//            UserResponse user=userClient.getUserInternal(token.get().getUserId());
//            logger.info("User {} logged out successfully",user.getUsername());
//            auditClient.save(new AuditRequest(user.getUsername(),"LOGOUT","User logged out"));
//        }

	@Transactional
	public SingleResponse<PinValidationResponse> validatePin(String userId, PinValidationRequest request) {

		MdmUser mdmUser = userRepository.findById(Integer.parseInt(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));

		String enteredPin = request.getSecurePin();

		MdmUserUeMapping mdmUserUeMapping = mdmUserUeRepository
				.findMdmUserUeMappingByMdmUserId(Integer.parseInt(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.UE_MAPPING_NOT_FOUND, 404));

		if (enteredPin == null || !enteredPin.matches("^\\d{6}$")) {
			throw new CustomException(CustomStatus.INVALID_PIN, 400);
		}

		MdmUe device = mdmUeRepository.findById(mdmUserUeMapping.getMdmUeId().getId())
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));

		if (device.getStatus() == 0) {
			throw new CustomException(CustomStatus.DEVICE_LOCKED, 401);
		}

		String dbUuid = device.getDeviceUUID() != null ? device.getDeviceUUID().toString().trim() : "";
		String reqUuid = request.getDeviceUUID() != null ? request.getDeviceUUID().toString().trim() : "";

//		if (!dbUuid.equalsIgnoreCase(reqUuid)) {
//			throw new CustomException(CustomStatus.DEVICE_NOT_FOUND, 401);
//		}

		if (device.getSecurePin().equals(enteredPin)) {
			handleSuccessfulLogin(device);
			String accessToken = jwtUtil.generateToken(mdmUser.getId(), mdmUser.getMdmRoleId().getId());// TODO userId
																										// is not
																										// present in
																										// the MDMUE
																										// table
			// how to fetch user ID from the Mdmuser table
			String refreshToken = jwtUtil.generateRefreshToken(mdmUser.getId());

			PinValidationResponse response = new PinValidationResponse(accessToken, refreshToken);
			return new SingleResponse<>(response, CustomStatus.SUCCESS);
		} else {
			return handleFailedLogin(device);
		}
	}
	
	private void handleSuccessfulLogin(MdmUe device) {
		if (device.getFailedLoginCount() > 0 && device.getFailedLoginCount() != AppConstants.MAX_LOGIN_ATTEMPTS) {
			device.setFailedLoginCount(0);
			mdmUeRepository.save(device);
		}
	}
	
	private SingleResponse<PinValidationResponse> handleFailedLogin(MdmUe device) {
		int updatedAttempts = device.getFailedLoginCount() + 1;
		device.setFailedLoginCount(updatedAttempts);

		if (updatedAttempts >= AppConstants.MAX_LOGIN_ATTEMPTS) {
			device.setStatus(0); // Lock device
			mdmUeRepository.save(device);
			throw new CustomException(CustomStatus.DEVICE_LOCKED, 401);
		} else {
			mdmUeRepository.save(device);
			int remaining = AppConstants.MAX_LOGIN_ATTEMPTS - updatedAttempts;
			throw new CustomException("Remaining Attempts " + remaining, CustomStatus.INCORRECT_PIN, 401);
		}
	}

	// ADMIN WILL UPDATE THE PIN
	public SingleResponse<?> updatePin(String adminId, String deviceId, PinChangeRequest request) {

		MdmUser adminUser = userRepository.findById(Integer.parseInt(adminId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));

		MdmUe device = mdmUeRepository.findByDeviceId(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 401));

		if (request.getNewPin().equals(request.getOldPin())) {
			throw new CustomException(CustomStatus.OLD_AND_NEW_PIN_SAME, 400);
		}

		if (request.getNewPin() == null || !request.getNewPin().matches("^\\d{6}$")) {
			throw new CustomException(CustomStatus.INVALID_PIN, 400);
		}

		if (!device.getSecurePin().equals(request.getOldPin())) {
			throw new CustomException(CustomStatus.INCORRECT_OLD_PIN, 401);
		}

		device.setUpdatedAt(LocalDate.now());
		device.setUpdatedBy(adminUser.getId().toString());
		device.setSecurePin(request.getNewPin());

		mdmUeRepository.save(device);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<?> signUp(String serviceId, String usrPass,UUID deviceUUID) {
		MdmUser user = new MdmUser();
			user = userRepository.findMdmUserByServiceId(serviceId)
					.orElseThrow(() -> new CustomException("User not found", CustomStatus.BAD_REQUEST, 400));
		if (user.getUserStats() == 2)
			throw new CustomException("User ID not found", CustomStatus.BAD_REQUEST, 400);
		if (user.isSignupStatus() == true)
			throw new CustomException("User already signed up, please go to login page",
					CustomStatus.USER_ALREADY_SIGNED_UP, 400);
		MdmUe device = new MdmUe();
		System.out.println("deviceUUID: "+deviceUUID);
		device = mdmUeRepository.findMdmUeByDeviceUUID(deviceUUID)
				.orElseThrow(() -> new CustomException("Device not found", CustomStatus.BAD_REQUEST, 400));
		Integer deviceId = device.getId();
		System.out.println("deviceId : "+deviceId);
		MdmUserUeMapping mdmUserUeMapping = mdmUserUeRepository.findMdmUserUeMappingByMdmUeId(deviceId)
			    .orElseThrow(() -> new CustomException("Device id not found", CustomStatus.BAD_REQUEST, 400));
			MdmUser mappedUser = mdmUserUeMapping.getMdmUserId(); 
			if (mappedUser == null) {
			    throw new CustomException("User is not linked", 
			        CustomStatus.BAD_REQUEST, 400);
			}
			Integer mappedUserId = mappedUser.getId();
			if (!user.getId().equals(mappedUserId)) {
			    throw new CustomException("Device is not registered for this specific User Account",
			        CustomStatus.FORBIDDEN, 403);
			}	
		user.setUsrPass(passwordEncoder.encode(usrPass));
		user.setSignupStatus(true);
		userRepository.save(user);
		return new SingleResponse<>("Signup successful, please log in", CustomStatus.SUCCESS);
	}
}

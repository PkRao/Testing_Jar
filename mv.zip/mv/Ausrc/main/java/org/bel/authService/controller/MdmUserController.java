package org.bel.authService.controller;

import java.util.List;

import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.service.AuthService;
import org.bel.authService.service.MdmUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/users")

@AllArgsConstructor
public class MdmUserController {
	private final MdmUserService userService;
	
	@PostMapping("/addUser")
	public ResponseEntity<SingleResponse<AddUserResponse>> addUser(@RequestHeader("X-User-Id") Integer userId,@Valid @RequestBody AddUserRequest request) {
		SingleResponse<AddUserResponse> response = userService.addUser(userId,request);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/listUser")
	public ResponseEntity<SingleResponse<ListOfUsersResponse>> getAllUsers(){
		SingleResponse<ListOfUsersResponse> response = userService.getAllUsers();
		return ResponseEntity.ok(response);
	}
	
	@PatchMapping("/editUser/{userId}")
	public ResponseEntity<SingleResponse<?>> editUser(@Valid @RequestBody EditUserRequest request,@PathVariable Integer userId) {
		SingleResponse<?> response = userService.editUser(request,userId);
		return ResponseEntity.ok(response);
	} 
	
	@DeleteMapping("/deleteUser")
	public ResponseEntity<SingleResponse<?>> deleteUser(@RequestBody List<Integer> userIds) {
		SingleResponse<?> response = userService.deleteUser(userIds);
		return ResponseEntity.ok(response);
	}

}

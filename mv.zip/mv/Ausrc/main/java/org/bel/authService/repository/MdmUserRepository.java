package org.bel.authService.repository;
import org.bel.authService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

	@Repository
	public interface MdmUserRepository extends JpaRepository<MdmUser, Integer> {

//	    @Query(value = """
//	        SELECT mu.id, mu.usr_name, mu.user_stats, mu.failed_login_count, 
//	               mu.usr_pass, mu.signup_status,
//	               COALESCE(mue.id, NULL) AS mdm_ue__id
//	        FROM tcs_mdm.mdm_user mu
//	        LEFT JOIN tcs_mdm.mdm_user_ue_mapping mum ON mu.id = mum.mdm_user__id
//	        LEFT JOIN tcs_mdm.mdm_ue mue ON mum.mdm_ue__id = mue.id AND mue.status = 1
//	        WHERE mu.service_id = :serviceId
//	        """, nativeQuery = true)
	    Optional<MdmUser> findMdmUserByServiceId(@Param("serviceId") String serviceId);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = :count, u.userStats = :stats WHERE u.id = :id")
	    void updateFailedAttempts(@Param("id") Integer id, @Param("count") Integer count, @Param("stats") Integer stats);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = 0 WHERE u.id = :id")
	    void resetFailedAttempts(@Param("id") Integer id);
	    
	    List<MdmUser> findByUserStats(Integer userStats);
	    
	    List<MdmUser> findByUserStatsOrderByServiceIdAsc(Integer userStats);
	    
	    List<MdmUser> findAllByOrderByIdAsc();
	}

package org.bel.authService.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "laa_ue_location_hist", schema = "tcs_laa")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LaaUeLocationHist {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user__id")
	private MdmUser mdmUser;

	// Relationship: Many Location Histories per UE
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_ue__id")
	private MdmUe mdmUe;

	// Relationship: Many Histories per Map Entry
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user_ue_map__id")
	private MdmUserUeMapping mdmUserUeMappin;

	// Relationship: Many Histories per Node
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_node__id")
	private MdmNode mdmNode;

	@Column(name = "latitude", precision = 10, scale = 6)
	private BigDecimal latitude;

	@Column(name = "longitude", precision = 10, scale = 6)
	private BigDecimal longitude;


	@Column(name = "battery_avail", precision = 5, scale = 2)
	private BigDecimal batteryAvail;

	@CreationTimestamp
	@Column(name = "created_at")
	private LocalDateTime createdAt;

	@Column(name = "created_time")
	private LocalDateTime createdTime;

	// Geometry (PostGIS Geography)
	// We store this as a Point. If need full GeoJSON handling, consider a
	// custom converter.
//	@Column(name = "geom")
//	private Point geom;
// OR
//	private Geometry geom; //TODO Need dependency of Geometry and Point
}

package org.bel.authService.dto.responseDto;

import lombok.Data;

@Data

public class DeviceListUserResponse {
	private Integer userId;
	private String serviceId;
	private String usrName;

}

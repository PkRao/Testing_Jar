package org.bel.authService.repository;

import org.bel.authService.entity.MdmUserType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserTypeRepository extends JpaRepository<MdmUserType, Integer>{

}

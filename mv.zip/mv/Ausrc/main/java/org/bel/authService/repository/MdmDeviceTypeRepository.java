package org.bel.authService.repository;

import java.util.List;
import java.util.Optional;

import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface MdmDeviceTypeRepository extends JpaRepository<MdmDeviceType, Integer>{
	Optional<MdmDeviceType> findByDeviceType(String deviceType);

	List<MdmDeviceType> findAllByOrderByIdAsc();
}

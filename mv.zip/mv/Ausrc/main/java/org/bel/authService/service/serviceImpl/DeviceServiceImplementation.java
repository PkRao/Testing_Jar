package org.bel.authService.service.serviceImpl;

import org.bel.authService.dto.responseDto.*;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.responseDto.DeviceStatsResponse.DeviceDetail;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.entity.LaaUeLocationHist;
import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.repository.LaaUeLocationHistRepository;
import org.bel.authService.repository.MdmDeviceTypeRepository;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmNodeRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.service.DeviceService;
import org.bel.authService.service.MdmUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j

public class DeviceServiceImplementation implements DeviceService {
	private final MdmUeRepository mdmUeRepository;
	private final MdmUserUeMappingRepository mdmUserUeMappingRepository;
	private final MdmUserRepository userRepository;
	private final MdmDeviceTypeRepository mdmDeviceTypeRepository;
	private final LaaUeLocationHistRepository laaUeLocationHistRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;

	private static final double REFERENCE_LATITUDE = 13.053524;
	private static final double REFERENCE_LONGITUDE = 77.561265;

	@Transactional
	public SingleResponse<DeviceStatsResponse> getDeviceStats() {
		LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
		long totalDevices = mdmUeRepository.getTotalDevicesCount();
		Map<String, Object> groups = mdmUeRepository.getTacticalGroupCounts();
		Map<String, Object> counts = mdmUeRepository.getDeviceCounts(fourHoursAgo);
		int activeDevices = ((Number) counts.get("active_devices")).intValue();
		int detachedDevices = ((Number) counts.get("detached_devices")).intValue();
		int fencingViolations = ((Number) counts.get("fencing_violations")).intValue();
		int todayCount = ((Number) counts.get("today")).intValue();
		int criticalDevices = ((Number) counts.get("critical_devices")).intValue();
		long totalGroups = ((Number) groups.get("total_groups")).longValue();
		long activeGroups = ((Number) groups.get("active_groups")).longValue();
		int activePercentage = totalDevices > 0 ? Math.round((float) activeDevices / totalDevices * 100) : 0;
		int detachedPercentage = totalDevices > 0 ? Math.round((float) todayCount / detachedDevices * 100) : 0;
		int fencingPercentage = totalDevices > 0 ? Math.round((float) criticalDevices / fencingViolations * 100) : 0;
		int tacticalPercentage = totalGroups > 0 ? Math.round((float) activeGroups / totalGroups * 100) : 0;
		DeviceStatsResponse dto = DeviceStatsResponse.builder()
				.ueDevices(DeviceDetail.builder().total(totalDevices).value("Active " + activeDevices)
						.percentage(activePercentage).build())
				.detachedUe(DeviceDetail.builder().total(detachedDevices).value("Today " + todayCount)
						.percentage(detachedPercentage).build())
				.fencingViolation(DeviceDetail.builder().total(fencingViolations).value("Critical " + criticalDevices)
						.percentage(fencingPercentage).build())
				.tacticalGroups(DeviceDetail.builder().total(totalGroups).value("Active " + activeGroups)
						.percentage(tacticalPercentage).build())
				.build();
		return new SingleResponse<>(dto, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceListResponse> getDeviceList() {
		List<MdmUser> mdmUsers = userRepository.findAllByOrderByIdAsc();
		List<MdmUserUeMapping> allMappings = mdmUserUeMappingRepository.findAll();
		Map<Integer, MdmUserUeMapping> mappingMap = allMappings.stream()
				.collect(Collectors.toMap(mdmUserMap -> mdmUserMap.getMdmUserId().getId(), mapping -> mapping,
						(existing, replacement) -> existing));
		Set<Integer> deviceIds = allMappings.stream().map(m -> m.getMdmUeId().getId()).collect(Collectors.toSet());
		Map<Integer, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
				.collect(Collectors.toMap(MdmUe::getId, device -> device));
		List<DeviceListResponse> deviceListResponses = mdmUsers.stream().map(user -> {
			MdmUserUeMapping mapping = mappingMap.get(user.getId());
			if (mapping == null)
				return null;
			MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
			if (device == null)
				return null;
			DeviceListResponse response = new DeviceListResponse();
			response.setId(device.getId());
			response.setDeviceId(device.getDeviceId());
			response.setDeviceName(device.getDeviceName());
			if (device.getMdmDeviceType() != null) {
				response.setDeviceTypeId(device.getMdmDeviceType().getId());
				response.setDeviceType(device.getMdmDeviceType().getDeviceType());
			}
			response.setStatus(device.getStatus());
			response.setContactNo(device.getContactNo());
			DeviceListUserResponse userResponse = new DeviceListUserResponse();
			userResponse.setUserId(user.getId());
			userResponse.setServiceId(user.getServiceId());
			userResponse.setUsrName(user.getUsrName());
			response.setUsers(userResponse);
			response.setSecurePin(device.getSecurePin());
			return response;
		}).filter(Objects::nonNull).toList();
		return new SingleResponse(deviceListResponses, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceListTypeResponse> getDeviceListType(String type) {
		List<DeviceListTypeResponse> deviceListTypeResponses = null;
		switch (type) {
		case "ue_devices":
			List<MdmUe> devices = mdmUeRepository.findAllByOrderByIdAsc();
			List<LaaUeLocationHist> laaUeLocationHist = laaUeLocationHistRepository.findAll();
			Map<Integer, LaaUeLocationHist> mdmUeIdMap = laaUeLocationHist.stream().collect(Collectors.toMap(
					mdUeMap -> mdUeMap.getMdmUe().getId(), mapping -> mapping, (existing, replacement) -> existing));
			Set<Integer> userIds = laaUeLocationHist.stream().map(m -> m.getMdmUser().getId())
					.collect(Collectors.toSet());
			Map<Integer, MdmUser> userMap = userRepository.findAllById(userIds).stream()
					.collect(Collectors.toMap(MdmUser::getId, device -> device));
			deviceListTypeResponses = devices.stream().map(device -> {
				LaaUeLocationHist mapping = mdmUeIdMap.get(device.getId());
				if (mapping == null)
					return null;
				MdmUser user = userMap.get(mapping.getMdmUser().getId());
				DeviceListTypeResponse response = new DeviceListTypeResponse();
				response.setDeviceId(device.getDeviceId());
				response.setDeviceName(device.getDeviceName());
				response.setUsrName(user.getUsrName());
				Double distanceInMeters = mdmUeRepository.getDistanceForDevice(device.getDeviceId(),
						REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
				if (distanceInMeters != null) {
					double distanceInKm = distanceInMeters / 1000.0;
					String formattedDistance = String.format("%.2f km", distanceInKm);
					response.setDistance(formattedDistance);
				} else {
					response.setDistance("0.00 km");
				}
				LaaUeLocationHist deviceLocationHistory = mdmUeIdMap.get(device.getId());
				LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
				if (deviceLocationHistory.getCreatedTime() != null
						&& deviceLocationHistory.getCreatedTime().isAfter(fourHoursAgo)) {
					response.setStatus("Active");
				} else {
					response.setStatus("Inactive");
				}
				LocalDateTime currentTime = LocalDateTime.now();
				Duration duration = Duration.between(deviceLocationHistory.getCreatedTime(), currentTime);
				if (duration.getSeconds() < 60) {
					response.setLastUpdated("Just now");
				} else if (duration.toMinutes() < 60) {
					response.setLastUpdated(duration.toMinutes() + " mins ago");
				} else if (duration.toHours() < 24) {
					response.setLastUpdated(duration.toHours() + " hours ago");
				} else {
					response.setLastUpdated(duration.toDays() + " days ago");
				}
				return response;
			}).filter(Objects::nonNull).toList();
		}
		return new SingleResponse(deviceListTypeResponses, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceTypeResponse> getDeviceTypes() {
		List<MdmDeviceType> mdmDeviceTypes = mdmDeviceTypeRepository.findAllByOrderByIdAsc();
		List<DeviceTypeResponse> responseList = new ArrayList<>();
		for (MdmDeviceType mdmDeviceType : mdmDeviceTypes) {
			DeviceTypeResponse dto = new DeviceTypeResponse();
			dto.setId(mdmDeviceType.getId());
			dto.setName(mdmDeviceType.getDeviceType());
			responseList.add(dto);
		}
		return new SingleResponse(responseList, CustomStatus.SUCCESS);
	}

	@Override
	public SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Transactional
//	public SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage() {
////		List<MdmUserType> mdmUserType = mdmUserTypeRepository.findAll();	
////		List<LaaUeLocationHist> laaUeLocationHists = laaUeLocationHistRepository.findAll();
////		List<MdmUe> mdmUe = mdmUeRepository.findAll();
////		Integer total = mdmUeRepository.countAll();
////		for (LaaUeLocationHist laaUeLocationHist : laaUeLocationHists) {
////			Set<Integer> uniqueIds = laaUeLocationHists.stream()
////				    .map(LaaUeLocationHist::getMdmUe) 
////				    .map(MdmUe::getId)               
////				    .collect(Collectors.toSet());     
////				Integer distinctCount = uniqueIds.size();
////			Integer mdmUeId = laaUeLocationHist.getMdmUe().getId();
////			Integer count = mdmUeRepository.count(mdmUeId);
//
////		List<DeviceMappingPercentageResponse> responseList = new ArrayList<>();
////		for (MdmDeviceType mdmDeviceType : mdmDeviceTypes) {
//		List<LaaUeLocationHist> laaUeLocationHists = laaUeLocationHistRepository.findAll();
//		if (laaUeLocationHists.isEmpty()) {
//			System.out.println("No data found.");
//		}
//		List<MdmUserUeMapping> mappings = mdmUserUeMappingRepository.findAll();
//		Map<Integer, MdmUserType> deviceToUserTypeMap = new HashMap<>();
//		for (MdmUserUeMapping mapping : mappings) {
//			Integer mdmUeId = mapping.getMdmUeId().getId();
//			Integer mdmUserId = mapping.getMdmUserId().getId();
//			MdmUserType userType = null;
//			MdmUser user = userRepository.findById(mdmUserId)
//					.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
//			if (user != null) {
//				userType = user.getMdmUserTypeId();
//			}
//			if (userType != null && mdmUeId != null) {
//				deviceToUserTypeMap.put(mdmUeId, userType);
//			}
////		    Map<MdmUserType, Long> userTypeDeviceCounts = new HashMap<>();
//			Map<MdmUserType, Long> userTypeDeviceCounts = deviceToUserTypeMap.entrySet().stream()
//					.collect(Collectors.groupingBy(Map.Entry::getValue, Collectors.counting()));
//
//			for (LaaUeLocationHist hist : laaUeLocationHists) {
//				Integer deviceId = hist.getMdmUe().getId();
//				if (deviceId != null) {
//					MdmUserType userTypeWithDeviceId = deviceToUserTypeMap.get(deviceId);
//					List<Map.Entry<MdmUserType, Long>> sortedCounts = new ArrayList<>(userTypeDeviceCounts.entrySet());
//					sortedCounts.sort(Comparator.comparingLong(Map.Entry::getValue).reversed());
//
//				}
//
//				for (LaaUeLocationHist hist : laaUeLocationHists) {
//					MdmUser user = hist.getMdmUser();
//					if (user != null) {
//						MdmUserType userType = user.getMdmUserTypeId();
//						if (userType != null) {
//							deviceToUserTypeMap.merge(device.getId(), userType, (existing, incoming) -> existing);
//						}
//					}
//				}
//
//				// 2. Group by User Type and Count Distinct Devices
//				Map<MdmUserType, Long> userTypeDeviceCounts = deviceToUserTypeMap.entrySet().stream()
//						.collect(Collectors.groupingBy(Map.Entry::getValue, // Group by UserType
//								Collectors.counting() // Count the entries (devices) for that type
//						));
//
//				// 3. Sort by count descending
//				List<Map.Entry<MdmUserType, Long>> sortedCounts = new ArrayList<>(userTypeDeviceCounts.entrySet());
//				sortedCounts.sort(Comparator.comparingLong(Map.Entry::getValue).reversed());
//
//				// 4. Assign Ranks
//				List<RankedUserTypeDTO> result = new ArrayList<>();
//				for (int i = 0; i < sortedCounts.size(); i++) {
//					Map.Entry<MdmUserType, Long> entry = sortedCounts.get(i);
//					result.add(new RankedUserTypeDTO(entry.getKey().getId(), // user_type_id
//							entry.getKey().getUsrType(), // user_type_name
//							entry.getValue(), // mapped_devices
//							i + 1 // rank
//					));
//				}
//
//				// Output result
//				System.out.println("Rank | UserType Name | Device Count");
//				for (RankedUserTypeDTO r : result) {
//					System.out.println(r.getRank() + " | " + r.getUserTypeName() + " | " + r.getMappedDevices());
//				}
//
//				DeviceMappingPercentageResponse dto = new DeviceMappingPercentageResponse();
//				dto.setTotal(total);
//
//				DeviceMappingPercentageResponse.CountDetail otherInfo = DeviceMappingPercentageResponse.CountDetail
//						.builder().name("Other").count(0).percentage(0.0f).build();
//
//				// 2. Build the main response
//				DeviceMappingPercentageResponse response = DeviceMappingPercentageResponse.builder().total(764)
//						.active(0).build();
//
//				// 3. MANUALLY add the "0" key to the dynamic map
//				// This is the trick to bypassing the Java variable naming rule
//				response.getDynamicFields().put("0", otherInfo);
//
//				dto.setId(mdmDeviceType.getId());
//				dto.setName(mdmDeviceType.getDeviceType());
//				responseList.add(dto);
//			}
//
//			Map<Integer, MdmUserUeMapping> mappingMap = allMappings.stream()
//					.collect(Collectors.toMap(mdmUserMap -> mdmUserMap.getMdmUserId().getId(), mapping -> mapping,
//							(existing, replacement) -> existing));
//			Set<Integer> deviceIds = allMappings.stream().map(m -> m.getMdmUeId().getId()).collect(Collectors.toSet());
//			Map<Integer, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
//					.collect(Collectors.toMap(MdmUe::getId, device -> device));
//			List<DeviceListResponse> deviceListResponses = mdmUsers.stream().map(user -> {
//				MdmUserUeMapping mapping = mappingMap.get(user.getId());
//				if (mapping == null)
//					return null;
//				MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
//				if (device == null)
//					return null;
//				DeviceListResponse response = new DeviceListResponse();
//				response.setId(device.getId());
//				response.setDeviceId(device.getDeviceId());
//				response.setDeviceName(device.getDeviceName());
//				if (device.getMdmDeviceType() != null) {
//					response.setDeviceTypeId(device.getMdmDeviceType().getId());
//					response.setDeviceType(device.getMdmDeviceType().getDeviceType());
//				}
//				response.setStatus(device.getStatus());
//				response.setContactNo(device.getContactNo());
//				DeviceListUserResponse userResponse = new DeviceListUserResponse();
//				userResponse.setUserId(user.getId());
//				userResponse.setServiceId(user.getServiceId());
//				userResponse.setUsrName(user.getUsrName());
//				response.setUsers(userResponse);
//				response.setSecurePin(device.getSecurePin());
//				return response;
//			}).filter(Objects::nonNull).toList();
//			return new SingleResponse(deviceListResponses, CustomStatus.SUCCESS);
//		}
//	}
}
//package org.bel.authService.service;
//
//import org.bel.authService.dto.requestDto.AssignRoleToEmployeeRequest;
//import org.bel.authService.dto.responseDto.PermissionResponse;
//import org.bel.authService.dto.responseDto.RolesResponse;
//import org.bel.authService.dto.responseDto.SingleResponse;
//
//import java.util.List;
//
//public interface RoleService {
//    SingleResponse<List<RolesResponse>> getAllRoles();
//
//    SingleResponse<?> assignRoleToEmployee(AssignRoleToEmployeeRequest request, String adminId);
//
//    SingleResponse<List<PermissionResponse>> getPermissionsForRole(Long roleId);
//
//    SingleResponse<?> assignPermissionsToRole(Long roleId, Long permissionId, String adminId);
//}

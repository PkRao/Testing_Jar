package org.bel.authService.entity;

import java.time.LocalDate;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="mdm_ue", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MdmUe {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name="device_id")
	private String deviceId;
	
	@Column(name="device_name")
	private String deviceName;
	
	@Column(name="manufacture_name")
	private String manufactureName;
	
	@Column(name="contact_no")
	private String contactNo;
	
	@Column(name="created_at")
	private LocalDate createdAt;
	
	@Column(name="updated_at")
	private LocalDate updatedAt;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@Column(name="device_type")
	private String deviceType;
	
	@Column(name="imei_number")
	private String imeiNumber;
	
	@Column(name="sim_number")
	private String simNumber;
	
	@Column(name = "device_uuid", unique = true)
	private UUID deviceUUID;
	
	@ManyToOne
    @JoinColumn(name="mdm_os_type__id")
	private MdmOsType mdmOsTypeId;
	
	@Column(name="status")
	private Integer status;
	
	@ManyToOne
    @JoinColumn(name="mdm_device_type__id")
	private MdmDeviceType mdmDeviceType;
	
	@Column(name="failed_login_count")
	private Integer failedLoginCount;
	
	@Column(name="secure_pin", length = 6)
	private String securePin;

}

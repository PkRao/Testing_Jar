package org.bel.authService.dto.requestDto;

import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PinValidationRequest {
    @Size(min = 6, max = 6, message = "Secure pin must be of 6 digits")
	@NotBlank(message = "Secure pin is required")
	private String securePin;
	
	@NotBlank(message = "Device UUID is required")
	private String deviceUUID;
}

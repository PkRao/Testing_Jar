package org.bel.authService.controller;

import org.bel.authService.dto.requestDto.LoginRequest;
import org.bel.authService.dto.responseDto.DeviceListResponse;
import org.bel.authService.dto.responseDto.DeviceListTypeResponse;
import org.bel.authService.dto.responseDto.DeviceMappingPercentageResponse;
import org.bel.authService.dto.responseDto.DeviceStatsResponse;
import org.bel.authService.dto.responseDto.DeviceTypeResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.service.DeviceService;
import org.bel.authService.service.MdmUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/device")
@AllArgsConstructor

public class DeviceController {
	private final DeviceService deviceService;
	@GetMapping("/deviceStats")
	public ResponseEntity<SingleResponse<DeviceStatsResponse>> getDeviceStats() {
		SingleResponse<DeviceStatsResponse> response = deviceService.getDeviceStats();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceList")
	public ResponseEntity<SingleResponse<DeviceListResponse>> getDeviceList() {
		SingleResponse<DeviceListResponse> response = deviceService.getDeviceList();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceList/{type}")
	public ResponseEntity<SingleResponse<DeviceListTypeResponse>> getDeviceListType(@PathVariable String type) {
		SingleResponse<DeviceListTypeResponse> response = deviceService.getDeviceListType(type);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceTypes")
	public ResponseEntity<SingleResponse<DeviceTypeResponse>> getDeviceTypes() {
		SingleResponse<DeviceTypeResponse> response = deviceService.getDeviceTypes();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceMappingPercentage")
	public ResponseEntity<SingleResponse<DeviceMappingPercentageResponse>> getDeviceMappingPercentage() {
		SingleResponse<DeviceMappingPercentageResponse> response = deviceService.getDeviceMappingPercentage();
		return ResponseEntity.ok(response);
	}

}

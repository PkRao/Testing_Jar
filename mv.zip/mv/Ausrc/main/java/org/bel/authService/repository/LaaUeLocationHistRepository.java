package org.bel.authService.repository;

import java.time.LocalDateTime;
import java.util.Optional;
import org.bel.authService.entity.LaaUeLocationHist;
import org.bel.authService.entity.MdmDeviceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaUeLocationHistRepository extends JpaRepository<LaaUeLocationHist, Integer>{
	Optional<LaaUeLocationHist> findLaaUeLocationHistByMdmUe(Integer mdmUeId);
}

package org.bel.authService.repository;

import org.bel.authService.entity.MdmLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmLevelRepository extends JpaRepository<MdmLevel, Integer>{

}

package org.bel.authService.exception;

public class UnauthorisedException extends  RuntimeException{

    public UnauthorisedException(String message){
        super(message);
    }
}

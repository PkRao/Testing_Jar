//package org.bel.authService.service;
//
//import org.bel.authService.dto.requestDto.InternalRegisterLoginRequest;
//import org.bel.authService.dto.responseDto.SingleResponse;
//
//import java.util.List;
//import java.util.Map;
//
//public interface InternalAuthService {
//    SingleResponse<?> registerEmployeeCredentials(InternalRegisterLoginRequest request);
//
//    SingleResponse<Map<Long, Long>> getRoleIdsForEmployees(List<Long> employeeIds);
//}

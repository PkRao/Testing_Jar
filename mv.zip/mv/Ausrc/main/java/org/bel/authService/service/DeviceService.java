package org.bel.authService.service;

import org.bel.authService.dto.responseDto.*;
import org.bel.authService.dto.responseDto.*;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.validation.Valid;

public interface DeviceService {
	SingleResponse<DeviceStatsResponse> getDeviceStats();
	
	SingleResponse<DeviceListResponse> getDeviceList();
	
	SingleResponse<DeviceListTypeResponse> getDeviceListType(String type);
	
	SingleResponse<DeviceTypeResponse> getDeviceTypes();
	
	SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage();
}

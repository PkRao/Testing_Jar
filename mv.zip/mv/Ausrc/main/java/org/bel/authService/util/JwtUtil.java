package org.bel.authService.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.RefreshToken;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.RefreshTokenRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtUtil {
	private final RefreshTokenRepository refreshTokenRepository;
	@Value("${app.jwt.secret}")
	private String secret;

	@Value("${app.jwt.token-expiry-time}")
	private Long jwtExpiration;

	@Value("${app.jwt.refresh-token-time}")
	private Long refreshExpiration;
	
	private final MdmUserRepository mdmUserRepository;

	public String generateToken(Integer userId, Integer roleId) {
		log.info("Token generation started");
		Map<String, Object> claims = new HashMap<>();
		claims.put("role", roleId.toString());
//		claims.put("loginTime", loginTime);
		String jwtId = UUID.randomUUID().toString();
		
		log.info("DEBUG: Generated token");
		return Jwts.builder()
				.setClaims(claims)
				.setId(jwtId)
				.setSubject(userId.toString())
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
				.signWith(getSignKey(), SignatureAlgorithm.HS256)
				.compact();
	}

	public String generateRefreshToken(Integer userId) {
		MdmUser user = mdmUserRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));

		RefreshToken token = new RefreshToken();
		token.setToken(UUID.randomUUID().toString());
		token.setUserId(user.getId());
		token.setExpiryDate(LocalDateTime.now().plusSeconds(refreshExpiration));
		refreshTokenRepository.save(token);
		return token.getToken();
	}

	public Claims getClaims(String token) {
		return Jwts.parserBuilder()
				.setSigningKey(getSignKey())
				.build()
				.parseClaimsJws(token)
				.getBody();
	}

	private Key getSignKey() {
		log.info("DEBUG: Getting sign key");
		byte[] keyBytes = Decoders.BASE64.decode(secret);
		return Keys.hmacShaKeyFor(keyBytes);
	}
}

package org.bel.authService.repository;

import org.bel.authService.entity.MdmRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmRoleRepository extends JpaRepository<MdmRole, Integer> {

}

package org.bel.authService.exception;

public class BadRequestException extends  RuntimeException{

    public BadRequestException(String message){
        super(message);
    }
}

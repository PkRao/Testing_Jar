package org.bel.authService.dto.requestDto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EditUserRequest {
    private String serviceId;
    private Integer mdmNodeId;
    private Integer mdmRoleId;
    private Integer mdmUserTypeId;
    private String usrName;

}

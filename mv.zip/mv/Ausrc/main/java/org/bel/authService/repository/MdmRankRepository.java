package org.bel.authService.repository;

import org.bel.authService.entity.MdmRank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmRankRepository extends JpaRepository<MdmRank, Integer>{

}

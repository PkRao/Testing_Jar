package org.bel.authService.dto.responseDto;

import org.bel.authService.enums.CustomStatus;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SingleResponse<T> {

	private T data;
	private Response response;;
	

	public SingleResponse(T data, CustomStatus status) {
		this.data = data;
		this.response = new Response(status.getCode(), status.getMessage());
	}
	
	public SingleResponse(T data, Response response) {
        this.data = data;
        this.response = response;
    }

//	public SingleResponse(T data, String message, CustomStatus status) {
//		this.response = new StatusCode(status);
//		this.message = message;
//		this.data = data;
//	}
}

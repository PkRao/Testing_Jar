package org.bel.authService.dto.responseDto;

import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class DeviceListTypeResponse {
	private String deviceId;
	private String deviceName;
	private String usrName;
	private String distance;
	private String status;
	private String lastUpdated;
}

package org.bel.authService.dto.requestDto;

import java.sql.Date;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class AddUserRequest {
	 	@NotBlank(message = "'ServiceId' is required")
	    private String serviceId;
	 	
	    @NotNull(message="'MdmNodeId' is required")
	    private Integer mdmNodeId;
	    
	    @NotNull(message = "'MdmRoleId' is required")
	    private Integer mdmRoleId;

	    @NotNull(message = "'MdmUserTypeId' is required")
	    private Integer mdmUserTypeId;
	    
	    @NotNull(message = "'UserStats' is required")
	    private Integer usrStats;
	    
	    @NotBlank(message = "'UsrName' is required")
	    private String usrName;
}

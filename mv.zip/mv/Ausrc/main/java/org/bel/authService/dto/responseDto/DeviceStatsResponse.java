package org.bel.authService.dto.responseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class DeviceStatsResponse {
	private DeviceDetail ueDevices;
	private DeviceDetail detachedUe;
	private DeviceDetail fencingViolation;
	private DeviceDetail tacticalGroups;
	
	@Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DeviceDetail {
        private long total;
        private String value;   
        private int percentage;
    }
}

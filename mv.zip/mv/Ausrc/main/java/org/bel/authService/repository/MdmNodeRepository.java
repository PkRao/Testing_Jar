package org.bel.authService.repository;

import org.bel.authService.entity.MdmNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmNodeRepository extends JpaRepository<MdmNode, Integer>{

}

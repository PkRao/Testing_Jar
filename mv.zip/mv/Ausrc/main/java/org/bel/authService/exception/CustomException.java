package org.bel.authService.exception;

import org.bel.authService.enums.CustomStatus;

public class CustomException extends RuntimeException{
	private final CustomStatus customStatus;
	private final int status;
	
	public CustomException(String message, CustomStatus customStatus, int status) {
		super(message);
		this.customStatus=customStatus;
		this.status=status;
	}
	
	public CustomException(CustomStatus customStatus, int status) {
		this.customStatus=customStatus;
		this.status=status;
	}
	

	public CustomStatus getCustomStatus() {
		return customStatus;
	}
	
	public int getStatus(){
		return status;
	}

}

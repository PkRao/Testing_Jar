package org.bel.authService.dto.responseDto;

import lombok.Data;

@Data

public class DeviceUsersResponse {
	private Integer id;
    private String serviceId;
    private String usrName;
}

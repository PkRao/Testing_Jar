package org.bel.authService.service;

import java.util.List;
import java.util.UUID;

import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;

public interface AuthService {
    SingleResponse<LoginResponse> login(String serviceId, String rawPassword);

	SingleResponse<?> validatePin(String userId, @Valid PinValidationRequest request);

	SingleResponse<?> updatePin(String adminId, String deviceId, @Valid PinChangeRequest request);

	SingleResponse<?> signUp(String serviceId, String usrPass,UUID deviceUUID);
}

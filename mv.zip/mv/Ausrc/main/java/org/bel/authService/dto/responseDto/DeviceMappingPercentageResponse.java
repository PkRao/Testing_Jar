package org.bel.authService.dto.responseDto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class DeviceMappingPercentageResponse {
	@JsonAnySetter
    private Map<String, Object> dynamicFields = new HashMap<>();
	private Integer total;
	private Integer active;
	
	@Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CountDetail {
        private String name;
        private Integer count;   
        private float percentage;
    }

}

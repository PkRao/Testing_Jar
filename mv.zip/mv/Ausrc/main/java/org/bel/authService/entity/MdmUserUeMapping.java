package org.bel.authService.entity;

import java.sql.Date;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
import lombok.*;

@Entity
@Data
@Table(name="mdm_user_ue_mapping", schema = "tcs_mdm")
@AllArgsConstructor
@NoArgsConstructor

public class MdmUserUeMapping {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@ManyToOne
    @JoinColumn(name="mdm_user__id")
	private MdmUser mdmUserId;
	
	@ManyToOne
    @JoinColumn(name="mdm_ue__id")
	private MdmUe mdmUeId;
	
	@Column(name="login_time")
	private Date loginTime;
	
	@Column(name="active")
	private boolean active;

}

package com.example.location.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

public record LocationSyncEvent(UUID eventId, String eventType, String entityType, String entityId, String sourceNodeId,
		String targetNodeId, Long version, BigDecimal latitude, BigDecimal longitude, BigDecimal accuracy,
		OffsetDateTime timestamp) {
}

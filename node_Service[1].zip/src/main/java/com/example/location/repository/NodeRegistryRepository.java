package com.example.location.repository;

import com.example.location.entity.NodeRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface NodeRegistryRepository extends JpaRepository<NodeRegistry, String> {
	// We use a native query to force the cast to 'inet'
    @Query(value = "SELECT * FROM node_registry WHERE ip_address = CAST(?1 AS inet)", nativeQuery = true)
    Optional<NodeRegistry> findByIpAddress(String ipAddress);

    List<NodeRegistry> findByStatusAndNodeIdNot(String status, String nodeId);
}

package com.example.location.repository;

import com.example.location.entity.UserLocationSyncState;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationSyncStateRepository extends JpaRepository<UserLocationSyncState, String> {
}

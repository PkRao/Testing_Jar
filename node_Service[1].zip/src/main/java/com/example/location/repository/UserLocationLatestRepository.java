package com.example.location.repository;

import com.example.location.entity.UserLocationLatest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationLatestRepository extends JpaRepository<UserLocationLatest, String> {
}

package com.example.location.controller;

import com.example.location.dto.*;
import com.example.location.service.LocationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/location")
@RequiredArgsConstructor
public class LocationController {
	private final LocationService service;

	@PostMapping("/users/{userId}")
	public ResponseEntity<LocationResponse> update(@PathVariable String userId,
			@Valid @RequestBody LocationUpdateRequest request) {
		return ResponseEntity.ok(service.updateLocation(userId, request));
	}
}

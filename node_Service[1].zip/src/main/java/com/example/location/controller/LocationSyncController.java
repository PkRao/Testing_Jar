package com.example.location.controller;

import com.example.location.dto.*;
import com.example.location.service.LocationSyncService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/internal/sync")
@RequiredArgsConstructor
public class LocationSyncController {
	private final LocationSyncService service;

	@PostMapping("/location")
	public ResponseEntity<SyncAckResponse> receive(@RequestBody LocationSyncEvent event) {
		return ResponseEntity.ok(service.process(event));
	}
}

package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "user_location_latest")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationLatest {
	@Id
	@Column(name = "user_id")
	private String userId;
	@Column(name = "node_id", nullable = false)
	private String nodeId;
	@Column(nullable = false, precision = 10, scale = 7)
	private BigDecimal latitude;
	@Column(nullable = false, precision = 10, scale = 7)
	private BigDecimal longitude;
	@Column(precision = 10, scale = 2)
	private BigDecimal accuracy;
	@Column(name = "location_timestamp", nullable = false)
	private OffsetDateTime locationTimestamp;
	@Column(name = "location_version", nullable = false)
	private Long locationVersion;
	@Column(name = "updated_at", nullable = false)
	private OffsetDateTime updatedAt;
}

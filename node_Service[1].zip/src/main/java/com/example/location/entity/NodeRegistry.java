package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "node_registry")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NodeRegistry {
	@Id
	@Column(name = "node_id")
	private String nodeId;
	@Column(name = "node_name", nullable = false)
	private String nodeName;
	@Column(name = "ip_address", columnDefinition = "inet")
	private String ipAddress;
	@Column(name = "port", nullable = false)
	private Integer port;
	@Column(name = "status", nullable = false)
	private String status;
	@Column(name = "created_at", nullable = false)
	private OffsetDateTime createdAt;
	@Column(name = "updated_at", nullable = false)
	private OffsetDateTime updatedAt;
}

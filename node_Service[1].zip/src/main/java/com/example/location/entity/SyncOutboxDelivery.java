package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "sync_outbox_delivery")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncOutboxDelivery {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "event_id", nullable = false)
	private UUID eventId;
	@Column(name = "target_node_id", nullable = false)
	private String targetNodeId;
	@Column(nullable = false)
	private String status;
	@Column(name = "retry_count", nullable = false)
	private Integer retryCount;
	@Column(name = "next_retry_at")
	private OffsetDateTime nextRetryAt;
	@Column(name = "created_at", nullable = false)
	private OffsetDateTime createdAt;
	@Column(name = "sent_at")
	private OffsetDateTime sentAt;
	@Column(name = "acknowledged_at")
	private OffsetDateTime acknowledgedAt;
	@Column(name = "last_error")
	private String lastError;
}

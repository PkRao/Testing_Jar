package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "processed_sync_event")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessedSyncEvent {
	@Id
	@Column(name = "event_id")
	private UUID eventId;
	@Column(name = "event_type", nullable = false)
	private String eventType;
	@Column(name = "source_node_id", nullable = false)
	private String sourceNodeId;
	@Column(name = "processed_at", nullable = false)
	private OffsetDateTime processedAt;
}

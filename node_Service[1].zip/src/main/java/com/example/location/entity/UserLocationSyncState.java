package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "user_location_sync_state")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationSyncState {
	@Id
	@Column(name = "user_id")
	private String userId;
	@Column(name = "last_synced_latitude")
	private BigDecimal lastSyncedLatitude;
	@Column(name = "last_synced_longitude")
	private BigDecimal lastSyncedLongitude;
	@Column(name = "last_synced_version")
	private Long lastSyncedVersion;
	@Column(name = "last_synced_at")
	private OffsetDateTime lastSyncedAt;
	@Column(name = "last_local_update_at")
	private OffsetDateTime lastLocalUpdateAt;
	@Column(name = "updated_at")
	private OffsetDateTime updatedAt;
}

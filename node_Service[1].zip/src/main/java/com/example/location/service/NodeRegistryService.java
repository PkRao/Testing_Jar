package com.example.location.service;

import com.example.location.entity.NodeRegistry;
import com.example.location.repository.NodeRegistryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NodeRegistryService {
	private final NodeRegistryRepository repo;
	private final CurrentNodeResolver resolver;

	public NodeRegistry getCurrentNode() {
		return resolver.getCurrentNode();
	}

	public String getCurrentNodeId() {
		return resolver.getCurrentNodeId();
	}

	public List<NodeRegistry> getOtherActiveNodes() {
		return repo.findByStatusAndNodeIdNot("ACTIVE", resolver.getCurrentNodeId());
	}
}

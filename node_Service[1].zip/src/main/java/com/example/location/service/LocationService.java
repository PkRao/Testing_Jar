package com.example.location.service;

import com.example.location.dto.*;
import com.example.location.entity.*;
import com.example.location.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class LocationService {
	private final UserLocationLatestRepository latestRepo;
	private final UserLocationHistoryRepository historyRepo;
	private final UserLocationSyncStateRepository stateRepo;
	private final SyncOutboxRepository outboxRepo;
	private final NodeRegistryService nodeRegistryService;
	private final ObjectMapper mapper;
	@Value("${location.sync.interval-seconds:60}")
	private long intervalSeconds;
	@Value("${location.sync.distance-threshold-meters:30}")
	private double distanceThreshold;

	@Transactional
	public LocationResponse updateLocation(String userId, LocationUpdateRequest req) {
		String node = nodeRegistryService.getCurrentNodeId();
		OffsetDateTime now = OffsetDateTime.now();
		UserLocationLatest old = latestRepo.findById(userId).orElse(null);
		long version = old == null ? 1L : old.getLocationVersion() + 1;
		latestRepo.save(UserLocationLatest.builder().userId(userId).nodeId(node).latitude(req.latitude())
				.longitude(req.longitude()).accuracy(req.accuracy()).locationTimestamp(req.timestamp())
				.locationVersion(version).updatedAt(now).build());
		historyRepo.save(UserLocationHistory.builder().userId(userId).nodeId(node).latitude(req.latitude())
				.longitude(req.longitude()).accuracy(req.accuracy()).locationTimestamp(req.timestamp())
				.locationVersion(version).recordedAt(now).build());
		UserLocationSyncState state = stateRepo.findById(userId)
				.orElseGet(() -> UserLocationSyncState.builder().userId(userId).build());
		boolean sync = shouldSynchronize(state, req.latitude(), req.longitude(), now);
		state.setLastLocalUpdateAt(now);
		state.setUpdatedAt(now);
		if (sync) {
			UUID id = UUID.randomUUID();
			LocationSyncEvent event = new LocationSyncEvent(id, "LOCATION_UPDATED", "USER_LOCATION", userId, node, null,
					version, req.latitude(), req.longitude(), req.accuracy(), req.timestamp());
			try {
				outboxRepo.save(SyncOutbox.builder().eventId(id).eventType(event.eventType())
						.entityType(event.entityType()).entityId(event.entityId()).sourceNodeId(node)
						.eventVersion(version).payload(mapper.writeValueAsString(event)).status("PENDING").retryCount(0)
						.createdAt(now).build());
			} catch (Exception e) {
				throw new IllegalStateException("Unable to create sync outbox event", e);
			}
			state.setLastSyncedLatitude(req.latitude());
			state.setLastSyncedLongitude(req.longitude());
			state.setLastSyncedVersion(version);
			state.setLastSyncedAt(now);
		}
		stateRepo.save(state);
		return new LocationResponse(userId, node, req.latitude(), req.longitude(), req.accuracy(), req.timestamp(),
				version);
	}

	private boolean shouldSynchronize(UserLocationSyncState s, BigDecimal lat, BigDecimal lon, OffsetDateTime now) {
		if (s.getLastSyncedAt() == null)
			return true;
		if (Duration.between(s.getLastSyncedAt(), now).getSeconds() >= intervalSeconds)
			return true;
		if (s.getLastSyncedLatitude() == null || s.getLastSyncedLongitude() == null)
			return true;
		return distance(s.getLastSyncedLatitude().doubleValue(), s.getLastSyncedLongitude().doubleValue(),
				lat.doubleValue(), lon.doubleValue()) >= distanceThreshold;
	}

	private double distance(double a, double b, double c, double d) {
		double R = 6371000.0, x = Math.toRadians(c - a), y = Math.toRadians(d - b);
		double h = Math.sin(x / 2) * Math.sin(x / 2)
				+ Math.cos(Math.toRadians(a)) * Math.cos(Math.toRadians(c)) * Math.sin(y / 2) * Math.sin(y / 2);
		return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
	}
}

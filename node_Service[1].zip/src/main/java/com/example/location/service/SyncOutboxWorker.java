package com.example.location.service;

import com.example.location.entity.*;
import com.example.location.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.OffsetDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class SyncOutboxWorker {
	private final SyncOutboxRepository outboxRepo;
	private final SyncOutboxDeliveryRepository deliveryRepo;
	private final NodeRegistryService nodeRegistryService;
	private final NodeSyncService nodeSyncService;
	@Value("${sync.outbox.batch-size:100}")
	private int batchSize;

	@Scheduled(fixedDelayString = "${sync.outbox.fixed-delay-ms:1000}")
	public void processOutbox() {
		outboxRepo.findEventsToProcess(OffsetDateTime.now()).stream().limit(batchSize).forEach(this::processEvent);
	}

	private void processEvent(SyncOutbox event) {
		for (NodeRegistry target : nodeRegistryService.getOtherActiveNodes()) {
			SyncOutboxDelivery d = deliveryRepo.findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
					.orElseGet(() -> deliveryRepo.save(
							SyncOutboxDelivery.builder().eventId(event.getEventId()).targetNodeId(target.getNodeId())
									.status("PENDING").retryCount(0).createdAt(OffsetDateTime.now()).build()));
			if ("ACKNOWLEDGED".equals(d.getStatus()))
				continue;
			if ("FAILED".equals(d.getStatus()) && d.getNextRetryAt() != null
					&& d.getNextRetryAt().isAfter(OffsetDateTime.now()))
				continue;
			nodeSyncService.send(event, d, target);
		}
	}
}

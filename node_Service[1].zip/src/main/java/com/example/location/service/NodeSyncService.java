package com.example.location.service;

import com.example.location.dto.*;
import com.example.location.entity.*;
import com.example.location.repository.SyncOutboxDeliveryRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.time.OffsetDateTime;

@Service
@RequiredArgsConstructor
public class NodeSyncService {
	private final RestClient restClient;
	private final SyncOutboxDeliveryRepository deliveryRepo;
	private final ObjectMapper mapper;

	public void send(SyncOutbox outbox, SyncOutboxDelivery delivery, NodeRegistry target) {
		try {
			LocationSyncEvent e = mapper.readValue(outbox.getPayload(), LocationSyncEvent.class);
			LocationSyncEvent targetEvent = new LocationSyncEvent(e.eventId(), e.eventType(), e.entityType(),
					e.entityId(), e.sourceNodeId(), target.getNodeId(), e.version(), e.latitude(), e.longitude(),
					e.accuracy(), e.timestamp());
			String url = "http://" + target.getIpAddress() + ":" + target.getPort() + "/internal/sync/location";
			ResponseEntity<SyncAckResponse> response = restClient.post().uri(url).body(targetEvent).retrieve()
					.toEntity(SyncAckResponse.class);
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				delivery.setStatus("ACKNOWLEDGED");
				delivery.setSentAt(OffsetDateTime.now());
				delivery.setAcknowledgedAt(OffsetDateTime.now());
				delivery.setLastError(null);
				deliveryRepo.save(delivery);
			}
		} catch (Exception ex) {
			fail(delivery, ex);
		}
	}

	private void fail(SyncOutboxDelivery d, Exception ex) {
		int retry = (d.getRetryCount() == null ? 0 : d.getRetryCount()) + 1;
		d.setRetryCount(retry);
		d.setStatus("FAILED");
		d.setNextRetryAt(OffsetDateTime.now().plusSeconds(Math.min(300, 10L * retry)));
		String msg = ex.getMessage();
		d.setLastError(msg != null && msg.length() > 2000 ? msg.substring(0, 2000) : msg);
		deliveryRepo.save(d);
	}
}
